-- MySQL dump 10.19  Distrib 10.3.30-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.3.30-MariaDB-1:10.3.30+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pagetypes_select` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tables_select` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lockToDomain` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  `ses_backuserid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('ab4e6b2a0846f85073d1bb672139b95d','172.18.0.7',3,1632299888,'a:6:{s:26:\"formProtectionSessionToken\";s:64:\"436d19fad04507b751cb76d1593c8fa784a3021aa721e86f7a01ecfa9b0e2f50\";s:27:\"core.template.flashMessages\";N;s:49:\"TYPO3\\CMS\\Backend\\Controller\\PageLayoutController\";a:1:{s:12:\"search_field\";N;}s:52:\"TYPO3\\CMS\\Recordlist\\Controller\\RecordListController\";a:1:{s:12:\"search_field\";N;}s:28:\"kitodo.default.flashMessages\";N;s:26:\"extbase.flashmessages.tx__\";N;}',0);
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lang` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `lockToDomain` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `disableIPlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `createdByAction` int(11) NOT NULL DEFAULT 0,
  `usergroup_cached_list` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1628075905,1628075358,0,0,0,0,0,NULL,'kitodo',0,'$argon2i$v=19$m=65536,t=16,p=1$SUVXZnhpNDlDbDA1WWNGVg$/ovMgziyrWnp6qdn2ovz60mG21vebGrkaLRPDeHuuo8',1,'','de','',NULL,0,'',NULL,'','a:18:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:10:{s:9:\"tx_beuser\";s:532:\"O:40:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\ModuleData\":2:{s:9:\"\0*\0demand\";O:36:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\Demand\":12:{s:11:\"\0*\0userName\";s:0:\"\";s:11:\"\0*\0userType\";i:0;s:9:\"\0*\0status\";i:0;s:9:\"\0*\0logins\";i:0;s:19:\"\0*\0backendUserGroup\";i:0;s:6:\"\0*\0uid\";N;s:16:\"\0*\0_localizedUid\";N;s:15:\"\0*\0_languageUid\";N;s:16:\"\0*\0_versionedUid\";N;s:6:\"\0*\0pid\";N;s:61:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_isClone\";b:0;s:69:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_cleanProperties\";a:0:{}}s:18:\"\0*\0compareUserList\";a:0:{}}\";s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"ad6c6673a0ce0bd828f9e86c3bc41bf4\";a:4:{i:0;s:6:\"Viewer\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:6:\"config\";s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:54:\"&edit%5Bsys_template%5D%5B1%5D=edit&columnsOnly=config\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"ad6c6673a0ce0bd828f9e86c3bc41bf4\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"web_layout\";a:2:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:352:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":12:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:12:\"\0*\0timeFrame\";i:0;s:9:\"\0*\0action\";i:0;s:14:\"\0*\0groupByPage\";b:0;s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";s:24:\"tools_dlfNewTenantModule\";a:1:{s:8:\"function\";s:0:\"\";}s:8:\"web_list\";a:0:{}s:6:\"web_ts\";a:7:{s:8:\"function\";s:87:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateObjectBrowserModuleFunctionController\";s:15:\"ts_browser_type\";s:5:\"setup\";s:16:\"ts_browser_const\";s:1:\"0\";s:19:\"ts_browser_fixedLgd\";s:1:\"1\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:25:\"tsbrowser_depthKeys_setup\";a:2:{s:6:\"plugin\";i:1;s:34:\"plugin.tx_dlf_searchindocumenttool\";i:1;}s:19:\"constant_editor_cat\";s:14:\"frontend login\";}s:13:\"system_config\";a:3:{s:4:\"tree\";s:8:\"confVars\";s:11:\"regexSearch\";b:0;s:13:\"node_confVars\";a:8:{s:31:\"SYS.caching.cacheConfigurations\";i:1;s:50:\"SYS.caching.cacheConfigurations.cache_pages.groups\";i:1;s:51:\"SYS.caching.cacheConfigurations.cache_pages.options\";i:1;s:11:\"SYS.caching\";i:1;s:43:\"SYS.caching.cacheConfigurations.cache_pages\";i:1;s:4:\"HTTP\";i:1;s:10:\"HTTP.proxy\";i:1;s:13:\"HTTP.proxy.no\";i:1;}}s:16:\"opendocs::recent\";a:1:{s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:6:\"Viewer\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1628075375;s:15:\"moduleSessionID\";a:9:{s:9:\"tx_beuser\";s:40:\"6f1f6e0d50b7a433c28cda55b113ac7d4f006e6d\";s:10:\"FormEngine\";s:40:\"6ddb24235e0f1255c5385911d53287e090ffc1db\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"6ddb24235e0f1255c5385911d53287e090ffc1db\";s:10:\"web_layout\";s:40:\"3627d990ceccd7f810762213fe6bb417f3a026b0\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"9aee03614c9157128aaaeb1135a0139ca3ccc195\";s:24:\"tools_dlfNewTenantModule\";s:40:\"6249c4b74f84d0d2bab825d3310b12e300f34e71\";s:8:\"web_list\";s:40:\"6249c4b74f84d0d2bab825d3310b12e300f34e71\";s:6:\"web_ts\";s:40:\"70f1060c6d7d39807269ab6252c616632604e2c2\";s:16:\"opendocs::recent\";s:40:\"7dafda009fa2285cbf59b6b260b669283665beb9\";}s:10:\"modulemenu\";s:2:\"{}\";s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1628166499}}\";s:10:\"inlineView\";s:72:\"a:1:{s:4:\"site\";a:1:{i:1;a:1:{s:13:\"site_language\";a:1:{i:2;s:1:\"0\";}}}}\";s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:1:{s:3:\"0_0\";s:1:\"1\";}}}}}',NULL,NULL,1,'',0,NULL,1629180200,0,NULL,0,NULL),(2,0,1628164991,1628164991,0,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$T3FiTGtSVU02TUJWYjFRZA$A5fPErW2fyV3Rzleyypb4i7z50/iOkbVy8Kzj+mir+g',1,'','','',NULL,0,'',NULL,'','a:13:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1628164991;}',NULL,NULL,1,'',0,NULL,0,0,NULL,0,NULL),(3,0,1629184457,1629184393,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$Y2dOZ0hnNUIvUnlxUjlVRg$hwsrFkUiggAx7NXrnTqHQKeMaJZaRtPFVmjiN2w0A44',1,'','','',NULL,0,'',NULL,'','a:25:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:9:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"web_layout\";a:2:{s:8:\"function\";s:1:\"2\";s:8:\"language\";s:1:\"0\";}s:6:\"web_ts\";a:8:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:19:\"constant_editor_cat\";s:14:\"frontend login\";s:15:\"ts_browser_type\";s:5:\"setup\";s:16:\"ts_browser_const\";s:1:\"0\";s:19:\"ts_browser_fixedLgd\";s:1:\"1\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:20:\"tsbrowser_conditions\";a:2:{s:32:\"ea7e4e96cee32bad059c5288b54c7c8f\";s:48:\"[traverse(request.getQueryParams(), \'html\') > 0]\";s:32:\"0b9183a8efaec73b8c90dc5d059cb24e\";s:0:\"\";}s:25:\"tsbrowser_depthKeys_setup\";a:7:{s:6:\"config\";i:1;s:4:\"page\";i:1;s:19:\"page.jsFooterInline\";i:1;s:22:\"page.jsFooterInline.10\";i:1;s:30:\"page.jsFooterInline.10.stdWrap\";i:1;s:7:\"page.10\";i:1;s:24:\"page.includeJSFooterlibs\";i:1;}}s:10:\"FormEngine\";a:2:{i:0;a:3:{s:32:\"d05de5db7a95716a106a7b65a59bfc32\";a:4:{i:0;s:6:\"Viewer\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:9:\"constants\";s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:57:\"&edit%5Bsys_template%5D%5B1%5D=edit&columnsOnly=constants\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"76f4971b4247dd8a00e0dddaf5c3b684\";a:4:{i:0;s:16:\"newspaper-issues\";i:1;a:6:{s:4:\"edit\";a:1:{s:16:\"tx_dlf_solrcores\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:39:\"&edit%5Btx_dlf_solrcores%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:16:\"tx_dlf_solrcores\";s:3:\"uid\";i:1;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"ad6c6673a0ce0bd828f9e86c3bc41bf4\";a:4:{i:0;s:6:\"Viewer\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:6:\"config\";s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:54:\"&edit%5Bsys_template%5D%5B1%5D=edit&columnsOnly=config\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"ad6c6673a0ce0bd828f9e86c3bc41bf4\";}s:16:\"opendocs::recent\";a:4:{s:32:\"d05de5db7a95716a106a7b65a59bfc32\";a:4:{i:0;s:6:\"Viewer\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:9:\"constants\";s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:57:\"&edit%5Bsys_template%5D%5B1%5D=edit&columnsOnly=constants\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"199ebfc2c53f4b17b21b27d7aba41662\";a:4:{i:0;s:30:\"[Translate to English:] Viewer\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"1\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B3%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=1\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:3;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:6:\"Viewer\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"ad6c6673a0ce0bd828f9e86c3bc41bf4\";a:4:{i:0;s:6:\"Viewer\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";s:6:\"config\";s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:54:\"&edit%5Bsys_template%5D%5B1%5D=edit&columnsOnly=config\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:9:\"tx_beuser\";s:532:\"O:40:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\ModuleData\":2:{s:9:\"\0*\0demand\";O:36:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\Demand\":12:{s:11:\"\0*\0userName\";s:0:\"\";s:11:\"\0*\0userType\";i:0;s:9:\"\0*\0status\";i:0;s:9:\"\0*\0logins\";i:0;s:19:\"\0*\0backendUserGroup\";i:0;s:6:\"\0*\0uid\";N;s:16:\"\0*\0_localizedUid\";N;s:15:\"\0*\0_languageUid\";N;s:16:\"\0*\0_versionedUid\";N;s:6:\"\0*\0pid\";N;s:61:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_isClone\";b:0;s:69:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_cleanProperties\";a:0:{}}s:18:\"\0*\0compareUserList\";a:0:{}}\";s:8:\"web_list\";a:1:{s:15:\"bigControlPanel\";s:1:\"1\";}s:13:\"system_config\";a:2:{s:4:\"tree\";s:8:\"confVars\";s:11:\"regexSearch\";b:0;}s:8:\"web_info\";a:1:{s:8:\"function\";s:48:\"TYPO3\\CMS\\Belog\\Module\\BackendLogModuleBootstrap\";}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";s:2:\"50\";s:8:\"edit_RTE\";i:1;s:20:\"edit_docModuleUpload\";i:1;s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";s:3:\"500\";s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1629184438;s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:10:\"copyLevels\";s:0:\"\";s:15:\"recursiveDelete\";i:0;s:18:\"resetConfiguration\";s:0:\"\";s:15:\"moduleSessionID\";a:8:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"a4aada48954a8314f4f1f831cb2b6ebf9989526e\";s:10:\"web_layout\";s:40:\"d4b3fc4b0207bf30943bb9ee92988e6aa2dbd753\";s:6:\"web_ts\";s:40:\"a4aada48954a8314f4f1f831cb2b6ebf9989526e\";s:10:\"FormEngine\";s:40:\"a4aada48954a8314f4f1f831cb2b6ebf9989526e\";s:16:\"opendocs::recent\";s:40:\"4d7b69c578d53508d9493aa369b87f74a7bcdae6\";s:9:\"tx_beuser\";s:40:\"1c4cd2d4586a7f3e2dcdca71649e5553f7ad41fc\";s:8:\"web_list\";s:40:\"d4b3fc4b0207bf30943bb9ee92988e6aa2dbd753\";s:8:\"web_info\";s:40:\"d4b3fc4b0207bf30943bb9ee92988e6aa2dbd753\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:1:{s:3:\"0_1\";s:1:\"1\";}}}}s:10:\"inlineView\";s:126:\"a:1:{s:4:\"site\";a:1:{i:1;a:2:{s:13:\"site_language\";a:2:{i:2;s:1:\"1\";i:4;s:0:\"\";}s:17:\"site_base_variant\";a:1:{i:0;s:1:\"0\";}}}}\";}',NULL,NULL,1,'',0,NULL,1632298967,0,NULL,0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cf_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_adminpanel_requestcache`
--

LOCK TABLES `cf_adminpanel_requestcache` WRITE;
/*!40000 ALTER TABLE `cf_adminpanel_requestcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_adminpanel_requestcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cf_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_adminpanel_requestcache_tags`
--

LOCK TABLES `cf_adminpanel_requestcache_tags` WRITE;
/*!40000 ALTER TABLE `cf_adminpanel_requestcache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_adminpanel_requestcache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_hash`
--

DROP TABLE IF EXISTS `cf_cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_hash`
--

LOCK TABLES `cf_cache_hash` WRITE;
/*!40000 ALTER TABLE `cf_cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_hash_tags`
--

DROP TABLE IF EXISTS `cf_cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_hash_tags`
--

LOCK TABLES `cf_cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_imagesizes`
--

DROP TABLE IF EXISTS `cf_cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_imagesizes`
--

LOCK TABLES `cf_cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cf_cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cf_cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_imagesizes_tags`
--

LOCK TABLES `cf_cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_pages`
--

DROP TABLE IF EXISTS `cf_cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_pages`
--

LOCK TABLES `cf_cache_pages` WRITE;
/*!40000 ALTER TABLE `cf_cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_pages_tags`
--

DROP TABLE IF EXISTS `cf_cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_pages_tags`
--

LOCK TABLES `cf_cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_pagesection`
--

DROP TABLE IF EXISTS `cf_cache_pagesection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_pagesection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_pagesection`
--

LOCK TABLES `cf_cache_pagesection` WRITE;
/*!40000 ALTER TABLE `cf_cache_pagesection` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_pagesection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_pagesection_tags`
--

DROP TABLE IF EXISTS `cf_cache_pagesection_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_pagesection_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_pagesection_tags`
--

LOCK TABLES `cf_cache_pagesection_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_pagesection_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_pagesection_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_rootline`
--

DROP TABLE IF EXISTS `cf_cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_rootline`
--

LOCK TABLES `cf_cache_rootline` WRITE;
/*!40000 ALTER TABLE `cf_cache_rootline` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_cache_rootline_tags`
--

DROP TABLE IF EXISTS `cf_cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_cache_rootline_tags`
--

LOCK TABLES `cf_cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cf_cache_rootline_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_extbase_datamapfactory_datamap`
--

DROP TABLE IF EXISTS `cf_extbase_datamapfactory_datamap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_extbase_datamapfactory_datamap` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_extbase_datamapfactory_datamap`
--

LOCK TABLES `cf_extbase_datamapfactory_datamap` WRITE;
/*!40000 ALTER TABLE `cf_extbase_datamapfactory_datamap` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_extbase_datamapfactory_datamap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_extbase_datamapfactory_datamap_tags`
--

DROP TABLE IF EXISTS `cf_extbase_datamapfactory_datamap_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_extbase_datamapfactory_datamap_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_extbase_datamapfactory_datamap_tags`
--

LOCK TABLES `cf_extbase_datamapfactory_datamap_tags` WRITE;
/*!40000 ALTER TABLE `cf_extbase_datamapfactory_datamap_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_extbase_datamapfactory_datamap_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ses_anonymous` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `usergroup` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `alias` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `legacy_overlay_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `alias` (`alias`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1629185218,1628166633,1,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'Viewer','/',1,'',1,0,'',0,0,'',0,'',0,0,'',0,'',0,'',1,1629185218,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0),(2,1,1629184744,1628486511,1,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'Kitodo Konfiguration','/1',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,'',0,0,'','',NULL,0,0,'',0,0,'',NULL,0,'',NULL,0,'',0),(3,0,1630422840,1630422828,3,0,0,0,0,'',256,NULL,0,1,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:38:{s:7:\"doktype\";i:1;s:5:\"title\";s:6:\"Viewer\";s:4:\"slug\";s:1:\"/\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:1;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,'',0,0,0,0,0,0,1,0,31,27,0,'[Translate to English:] Viewer','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,1,1630422840,NULL,'',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'',NULL,0,'',NULL,0,'',0),(4,1,1632299231,1630500948,3,0,1,0,0,'',128,'',0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,'',0,0,0,0,0,0,3,0,31,27,0,'Viewerdev','/viewerdev',1,'',0,0,'',0,0,'',0,'',0,0,'',0,'',0,'',0,1630500958,'','',0,'','','',0,0,0,0,'',0,0,'','','',0,0,'',0,0,'','',0,'','',0,'',0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `module_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local_foreign` (`uid_local`,`uid_foreign`),
  KEY `uid_foreign_tablefield` (`uid_foreign`,`tablenames`(40),`fieldname`(3),`sorting_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection`
--

DROP TABLE IF EXISTS `sys_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'static',
  `table_name` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection`
--

LOCK TABLES `sys_collection` WRITE;
/*!40000 ALTER TABLE `sys_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection_entries`
--

DROP TABLE IF EXISTS `sys_collection_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection_entries` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection_entries`
--

LOCK TABLES `sys_collection_entries` WRITE;
/*!40000 ALTER TABLE `sys_collection_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_domain`
--

DROP TABLE IF EXISTS `sys_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_domain` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `domainName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `getSysDomain` (`hidden`),
  KEY `getDomainStartPage` (`pid`,`hidden`,`domainName`(100)),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_domain`
--

LOCK TABLES `sys_domain` WRITE;
/*!40000 ALTER TABLE `sys_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1628075892,1628075892,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,0,1628075905,2,'BE',1,0,1,'be_users','{\"oldRecord\":{\"lang\":\"\"},\"newRecord\":{\"lang\":\"de\"}}',0),(2,0,1628166052,1,'BE',1,0,1,'tx_dlf_formats','{\"uid\":1,\"pid\":0,\"tstamp\":1628166052,\"crdate\":1628166052,\"cruser_id\":1,\"deleted\":0,\"type\":\"MODS\",\"root\":\"mods\",\"namespace\":\"http:\\/\\/www.loc.gov\\/mods\\/v3\",\"class\":\"Kitodo\\\\Dlf\\\\Format\\\\Mods\"}',0),(3,0,1628166052,1,'BE',1,0,2,'tx_dlf_formats','{\"uid\":2,\"pid\":0,\"tstamp\":1628166052,\"crdate\":1628166052,\"cruser_id\":1,\"deleted\":0,\"type\":\"TEIHDR\",\"root\":\"teiHeader\",\"namespace\":\"http:\\/\\/www.tei-c.org\\/ns\\/1.0\",\"class\":\"Kitodo\\\\Dlf\\\\Format\\\\TeiHeader\"}',0),(4,0,1628166052,1,'BE',1,0,3,'tx_dlf_formats','{\"uid\":3,\"pid\":0,\"tstamp\":1628166052,\"crdate\":1628166052,\"cruser_id\":1,\"deleted\":0,\"type\":\"ALTO\",\"root\":\"alto\",\"namespace\":\"http:\\/\\/www.loc.gov\\/standards\\/alto\\/ns-v2#\",\"class\":\"Kitodo\\\\Dlf\\\\Format\\\\Alto\"}',0),(5,0,1628166052,1,'BE',1,0,4,'tx_dlf_formats','{\"uid\":4,\"pid\":0,\"tstamp\":1628166052,\"crdate\":1628166052,\"cruser_id\":1,\"deleted\":0,\"type\":\"IIIF1\",\"root\":\"IIIF1\",\"namespace\":\"http:\\/\\/www.shared-canvas.org\\/ns\\/context.json\",\"class\":\"\"}',0),(6,0,1628166052,1,'BE',1,0,5,'tx_dlf_formats','{\"uid\":5,\"pid\":0,\"tstamp\":1628166052,\"crdate\":1628166052,\"cruser_id\":1,\"deleted\":0,\"type\":\"IIIF2\",\"root\":\"IIIF2\",\"namespace\":\"http:\\/\\/iiif.io\\/api\\/presentation\\/2\\/context.json\",\"class\":\"\"}',0),(7,0,1628166052,1,'BE',1,0,6,'tx_dlf_formats','{\"uid\":6,\"pid\":0,\"tstamp\":1628166052,\"crdate\":1628166052,\"cruser_id\":1,\"deleted\":0,\"type\":\"IIIF3\",\"root\":\"IIIF3\",\"namespace\":\"http:\\/\\/iiif.io\\/api\\/presentation\\/3\\/context.json\",\"class\":\"\"}',0),(8,0,1628166633,1,'BE',1,0,1,'pages','{\"uid\":1,\"pid\":0,\"tstamp\":1628166633,\"crdate\":1628166633,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Viewer\",\"slug\":\"\\/\",\"doktype\":1,\"TSconfig\":\"\",\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":\"\",\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":\"\",\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":\"\",\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"alias\":\"\",\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":\"\",\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":0,\"canonical_link\":\"\",\"categories\":0}',0),(9,0,1628166800,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0),(10,0,1628486511,1,'BE',1,0,2,'pages','{\"uid\":2,\"pid\":0,\"tstamp\":1628486511,\"crdate\":1628486511,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":128,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Kitodo Konfiguration\",\"slug\":\"\\/\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"alias\":\"\",\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"canonical_link\":\"\",\"categories\":0}',0),(11,0,1628486525,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:12:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(12,0,1628486528,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"a:12:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0),(13,0,1628486788,1,'BE',1,0,1,'tx_dlf_structures','{\"uid\":1,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Year\",\"index_name\":\"year\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(14,0,1628486788,1,'BE',1,0,2,'tx_dlf_structures','{\"uid\":2,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Volume\",\"index_name\":\"volume\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(15,0,1628486788,1,'BE',1,0,3,'tx_dlf_structures','{\"uid\":3,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Verse\",\"index_name\":\"verse\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(16,0,1628486788,1,'BE',1,0,4,'tx_dlf_structures','{\"uid\":4,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Titlepage\",\"index_name\":\"title_page\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(17,0,1628486788,1,'BE',1,0,5,'tx_dlf_structures','{\"uid\":5,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Text\",\"index_name\":\"text\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(18,0,1628486788,1,'BE',1,0,6,'tx_dlf_structures','{\"uid\":6,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Table\",\"index_name\":\"table\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(19,0,1628486788,1,'BE',1,0,7,'tx_dlf_structures','{\"uid\":7,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Subinventory\",\"index_name\":\"subinventory\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(20,0,1628486788,1,'BE',1,0,8,'tx_dlf_structures','{\"uid\":8,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Study\",\"index_name\":\"study\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(21,0,1628486788,1,'BE',1,0,9,'tx_dlf_structures','{\"uid\":9,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Stamp\",\"index_name\":\"stamp\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(22,0,1628486788,1,'BE',1,0,10,'tx_dlf_structures','{\"uid\":10,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Spine\",\"index_name\":\"spine\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(23,0,1628486788,1,'BE',1,0,11,'tx_dlf_structures','{\"uid\":11,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Section\",\"index_name\":\"section\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(24,0,1628486788,1,'BE',1,0,12,'tx_dlf_structures','{\"uid\":12,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Seal\",\"index_name\":\"seal\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(25,0,1628486788,1,'BE',1,0,13,'tx_dlf_structures','{\"uid\":13,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Scheme\",\"index_name\":\"scheme\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(26,0,1628486788,1,'BE',1,0,14,'tx_dlf_structures','{\"uid\":14,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Research Paper\",\"index_name\":\"research_paper\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(27,0,1628486788,1,'BE',1,0,15,'tx_dlf_structures','{\"uid\":15,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Report\",\"index_name\":\"report\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(28,0,1628486788,1,'BE',1,0,16,'tx_dlf_structures','{\"uid\":16,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Register\",\"index_name\":\"register\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(29,0,1628486788,1,'BE',1,0,17,'tx_dlf_structures','{\"uid\":17,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Provenance\",\"index_name\":\"provenance\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(30,0,1628486788,1,'BE',1,0,18,'tx_dlf_structures','{\"uid\":18,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Proceeding\",\"index_name\":\"proceeding\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(31,0,1628486788,1,'BE',1,0,19,'tx_dlf_structures','{\"uid\":19,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Privileges\",\"index_name\":\"privileges\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(32,0,1628486788,1,'BE',1,0,20,'tx_dlf_structures','{\"uid\":20,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Printers Mark\",\"index_name\":\"printers_mark\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(33,0,1628486788,1,'BE',1,0,21,'tx_dlf_structures','{\"uid\":21,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Printed Archives\",\"index_name\":\"printed_archives\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(34,0,1628486788,1,'BE',1,0,22,'tx_dlf_structures','{\"uid\":22,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Preprint\",\"index_name\":\"preprint\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(35,0,1628486788,1,'BE',1,0,23,'tx_dlf_structures','{\"uid\":23,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Preface\",\"index_name\":\"preface\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(36,0,1628486788,1,'BE',1,0,24,'tx_dlf_structures','{\"uid\":24,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Poster\",\"index_name\":\"poster\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(37,0,1628486788,1,'BE',1,0,25,'tx_dlf_structures','{\"uid\":25,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Plan\",\"index_name\":\"plan\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(38,0,1628486788,1,'BE',1,0,26,'tx_dlf_structures','{\"uid\":26,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Photograph\",\"index_name\":\"photograph\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(39,0,1628486788,1,'BE',1,0,27,'tx_dlf_structures','{\"uid\":27,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Periodical\",\"index_name\":\"periodical\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(40,0,1628486788,1,'BE',1,0,28,'tx_dlf_structures','{\"uid\":28,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Paste Down\",\"index_name\":\"paste_down\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(41,0,1628486788,1,'BE',1,0,29,'tx_dlf_structures','{\"uid\":29,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Paper\",\"index_name\":\"paper\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(42,0,1628486788,1,'BE',1,0,30,'tx_dlf_structures','{\"uid\":30,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Page\",\"index_name\":\"page\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(43,0,1628486788,1,'BE',1,0,31,'tx_dlf_structures','{\"uid\":31,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Ornament\",\"index_name\":\"ornament\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(44,0,1628486788,1,'BE',1,0,32,'tx_dlf_structures','{\"uid\":32,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Official Notification\",\"index_name\":\"official_notification\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(45,0,1628486788,1,'BE',1,0,33,'tx_dlf_structures','{\"uid\":33,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Note\",\"index_name\":\"note\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(46,0,1628486788,1,'BE',1,0,34,'tx_dlf_structures','{\"uid\":34,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Newspaper\",\"index_name\":\"newspaper\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(47,0,1628486788,1,'BE',1,0,35,'tx_dlf_structures','{\"uid\":35,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Musical Notation\",\"index_name\":\"musical_notation\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(48,0,1628486788,1,'BE',1,0,36,'tx_dlf_structures','{\"uid\":36,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Multivolume Work\",\"index_name\":\"multivolume_work\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(49,0,1628486788,1,'BE',1,0,37,'tx_dlf_structures','{\"uid\":37,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Month\",\"index_name\":\"month\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(50,0,1628486788,1,'BE',1,0,38,'tx_dlf_structures','{\"uid\":38,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Monograph\",\"index_name\":\"monograph\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(51,0,1628486788,1,'BE',1,0,39,'tx_dlf_structures','{\"uid\":39,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Map\",\"index_name\":\"map\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(52,0,1628486788,1,'BE',1,0,40,'tx_dlf_structures','{\"uid\":40,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Manuscript\",\"index_name\":\"manuscript\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(53,0,1628486788,1,'BE',1,0,41,'tx_dlf_structures','{\"uid\":41,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Master Thesis\",\"index_name\":\"master_thesis\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(54,0,1628486788,1,'BE',1,0,42,'tx_dlf_structures','{\"uid\":42,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Magister Thesis\",\"index_name\":\"magister_thesis\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(55,0,1628486788,1,'BE',1,0,43,'tx_dlf_structures','{\"uid\":43,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Letter\",\"index_name\":\"letter\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(56,0,1628486788,1,'BE',1,0,44,'tx_dlf_structures','{\"uid\":44,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Lecture\",\"index_name\":\"lecture\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(57,0,1628486788,1,'BE',1,0,45,'tx_dlf_structures','{\"uid\":45,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Leaflet\",\"index_name\":\"leaflet\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(58,0,1628486788,1,'BE',1,0,46,'tx_dlf_structures','{\"uid\":46,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Land Register\",\"index_name\":\"land_register\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(59,0,1628486788,1,'BE',1,0,47,'tx_dlf_structures','{\"uid\":47,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Judgement\",\"index_name\":\"judgement\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(60,0,1628486788,1,'BE',1,0,48,'tx_dlf_structures','{\"uid\":48,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Issue\",\"index_name\":\"issue\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(61,0,1628486788,1,'BE',1,0,49,'tx_dlf_structures','{\"uid\":49,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Inventory\",\"index_name\":\"inventory\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(62,0,1628486788,1,'BE',1,0,50,'tx_dlf_structures','{\"uid\":50,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Initial Decoration\",\"index_name\":\"initial_decoration\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(63,0,1628486788,1,'BE',1,0,51,'tx_dlf_structures','{\"uid\":51,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Index\",\"index_name\":\"index\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(64,0,1628486788,1,'BE',1,0,52,'tx_dlf_structures','{\"uid\":52,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Imprint\",\"index_name\":\"imprint\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(65,0,1628486788,1,'BE',1,0,53,'tx_dlf_structures','{\"uid\":53,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Image\",\"index_name\":\"image\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(66,0,1628486788,1,'BE',1,0,54,'tx_dlf_structures','{\"uid\":54,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Illustration\",\"index_name\":\"illustration\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(67,0,1628486788,1,'BE',1,0,55,'tx_dlf_structures','{\"uid\":55,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Habilitation Thesis\",\"index_name\":\"habilitation_thesis\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(68,0,1628486788,1,'BE',1,0,56,'tx_dlf_structures','{\"uid\":56,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Ground Plan\",\"index_name\":\"ground_plan\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(69,0,1628486788,1,'BE',1,0,57,'tx_dlf_structures','{\"uid\":57,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Fragment\",\"index_name\":\"fragment\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(70,0,1628486788,1,'BE',1,0,58,'tx_dlf_structures','{\"uid\":58,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Folder\",\"index_name\":\"folder\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(71,0,1628486788,1,'BE',1,0,59,'tx_dlf_structures','{\"uid\":59,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"File\",\"index_name\":\"file\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(72,0,1628486788,1,'BE',1,0,60,'tx_dlf_structures','{\"uid\":60,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Fascicle\",\"index_name\":\"fascicle\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(73,0,1628486788,1,'BE',1,0,61,'tx_dlf_structures','{\"uid\":61,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Ephemera\",\"index_name\":\"ephemera\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(74,0,1628486788,1,'BE',1,0,62,'tx_dlf_structures','{\"uid\":62,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Entry\",\"index_name\":\"entry\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(75,0,1628486788,1,'BE',1,0,63,'tx_dlf_structures','{\"uid\":63,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Engraved Titlepage\",\"index_name\":\"engraved_titlepage\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(76,0,1628486788,1,'BE',1,0,64,'tx_dlf_structures','{\"uid\":64,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Endsheet\",\"index_name\":\"endsheet\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(77,0,1628486788,1,'BE',1,0,65,'tx_dlf_structures','{\"uid\":65,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Edge\",\"index_name\":\"edge\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(78,0,1628486788,1,'BE',1,0,66,'tx_dlf_structures','{\"uid\":66,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Dossier\",\"index_name\":\"dossier\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(79,0,1628486788,1,'BE',1,0,67,'tx_dlf_structures','{\"uid\":67,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Document\",\"index_name\":\"document\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(80,0,1628486788,1,'BE',1,0,68,'tx_dlf_structures','{\"uid\":68,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Doctoral Thesis\",\"index_name\":\"doctoral_thesis\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(81,0,1628486788,1,'BE',1,0,69,'tx_dlf_structures','{\"uid\":69,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Diploma Thesis\",\"index_name\":\"diploma_thesis\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(82,0,1628486788,1,'BE',1,0,70,'tx_dlf_structures','{\"uid\":70,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Dedication\",\"index_name\":\"dedication\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(83,0,1628486788,1,'BE',1,0,71,'tx_dlf_structures','{\"uid\":71,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Day\",\"index_name\":\"day\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(84,0,1628486788,1,'BE',1,0,72,'tx_dlf_structures','{\"uid\":72,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Back Cover\",\"index_name\":\"cover_back\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(85,0,1628486788,1,'BE',1,0,73,'tx_dlf_structures','{\"uid\":73,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Front Cover\",\"index_name\":\"cover_front\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(86,0,1628486788,1,'BE',1,0,74,'tx_dlf_structures','{\"uid\":74,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Cover\",\"index_name\":\"cover\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(87,0,1628486788,1,'BE',1,0,75,'tx_dlf_structures','{\"uid\":75,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Corrigenda\",\"index_name\":\"corrigenda\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(88,0,1628486788,1,'BE',1,0,76,'tx_dlf_structures','{\"uid\":76,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Table of Contents\",\"index_name\":\"contents\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(89,0,1628486788,1,'BE',1,0,77,'tx_dlf_structures','{\"uid\":77,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Contained Work\",\"index_name\":\"contained_work\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(90,0,1628486788,1,'BE',1,0,78,'tx_dlf_structures','{\"uid\":78,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Colophon\",\"index_name\":\"colophon\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(91,0,1628486788,1,'BE',1,0,79,'tx_dlf_structures','{\"uid\":79,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Collation\",\"index_name\":\"collation\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(92,0,1628486788,1,'BE',1,0,80,'tx_dlf_structures','{\"uid\":80,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Chapter\",\"index_name\":\"chapter\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(93,0,1628486788,1,'BE',1,0,81,'tx_dlf_structures','{\"uid\":81,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Cartulary\",\"index_name\":\"cartulary\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(94,0,1628486788,1,'BE',1,0,82,'tx_dlf_structures','{\"uid\":82,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Bookplate\",\"index_name\":\"bookplate\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(95,0,1628486788,1,'BE',1,0,83,'tx_dlf_structures','{\"uid\":83,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Binding\",\"index_name\":\"binding\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(96,0,1628486788,1,'BE',1,0,84,'tx_dlf_structures','{\"uid\":84,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Bachelor Thesis\",\"index_name\":\"bachelor_thesis\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(97,0,1628486788,1,'BE',1,0,85,'tx_dlf_structures','{\"uid\":85,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Atlas\",\"index_name\":\"atlas\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(98,0,1628486788,1,'BE',1,0,86,'tx_dlf_structures','{\"uid\":86,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Article\",\"index_name\":\"article\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(99,0,1628486788,1,'BE',1,0,87,'tx_dlf_structures','{\"uid\":87,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Annotation\",\"index_name\":\"annotation\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(100,0,1628486788,1,'BE',1,0,88,'tx_dlf_structures','{\"uid\":88,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Album\",\"index_name\":\"album\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(101,0,1628486788,1,'BE',1,0,89,'tx_dlf_structures','{\"uid\":89,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Address\",\"index_name\":\"address\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(102,0,1628486788,1,'BE',1,0,90,'tx_dlf_structures','{\"uid\":90,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":0,\"label\":\"Additional\",\"index_name\":\"additional\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(103,0,1628486788,1,'BE',1,0,91,'tx_dlf_structures','{\"uid\":91,\"pid\":2,\"tstamp\":1628486788,\"crdate\":1628486788,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:6:{s:8:\\\"toplevel\\\";N;s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:8:\\\"oai_name\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"l10n_state\":null,\"toplevel\":1,\"label\":\"Act\",\"index_name\":\"act\",\"oai_name\":\"\",\"thumbnail\":0,\"status\":0}',0),(104,0,1628486790,1,'BE',1,0,1,'tx_dlf_metadataformat','{\"uid\":1,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:accessCondition[@type=\\\"info\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(105,0,1628486790,1,'BE',1,0,2,'tx_dlf_metadataformat','{\"uid\":2,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:accessCondition[@type=\\\"out of print work\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(106,0,1628486790,1,'BE',1,0,3,'tx_dlf_metadataformat','{\"uid\":3,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:accessCondition[@type=\\\"restriction on access\\\"]\\/@xlink:href\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(107,0,1628486790,1,'BE',1,0,4,'tx_dlf_metadataformat','{\"uid\":4,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:accessCondition[@type=\\\"local terms of use\\\"]\\/@xlink:href\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(108,0,1628486790,1,'BE',1,0,5,'tx_dlf_metadataformat','{\"uid\":5,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:accessCondition[@type=\\\"use and reproduction\\\"]\\/@xlink:href\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(109,0,1628486790,1,'BE',1,0,6,'tx_dlf_metadataformat','{\"uid\":6,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:subject\\/mods:cartographics\\/mods:coordinates\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(110,0,1628486790,1,'BE',1,0,7,'tx_dlf_metadataformat','{\"uid\":7,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$.metadata.[?(@.label==\'Kitodo\')].value\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(111,0,1628486790,1,'BE',1,0,8,'tx_dlf_metadataformat','{\"uid\":8,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:publicationStmt\\/teihdr:idno[@type=\\\"kitodo\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(112,0,1628486790,1,'BE',1,0,9,'tx_dlf_metadataformat','{\"uid\":9,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:identifier[@type=\\\"kitodo\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(113,0,1628486790,1,'BE',1,0,10,'tx_dlf_metadataformat','{\"uid\":10,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$[\'@id\']\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(114,0,1628486790,1,'BE',1,0,11,'tx_dlf_metadataformat','{\"uid\":11,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:publicationStmt\\/teihdr:idno[@type=\\\"recordIdentifier\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(115,0,1628486790,1,'BE',1,0,12,'tx_dlf_metadataformat','{\"uid\":12,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:recordInfo\\/mods:recordIdentifier\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(116,0,1628486790,1,'BE',1,0,13,'tx_dlf_metadataformat','{\"uid\":13,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:publicationStmt\\/teihdr:idno[@type=\\\"mmid\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(117,0,1628486790,1,'BE',1,0,14,'tx_dlf_metadataformat','{\"uid\":14,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:identifier[@type=\\\"ppn\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(118,0,1628486790,1,'BE',1,0,15,'tx_dlf_metadataformat','{\"uid\":15,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:publicationStmt\\/teihdr:idno[@type=\\\"opac\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(119,0,1628486790,1,'BE',1,0,16,'tx_dlf_metadataformat','{\"uid\":16,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:identifier[@type=\\\"opac\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(120,0,1628486790,1,'BE',1,0,17,'tx_dlf_metadataformat','{\"uid\":17,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$.metadata.[?(@.label==\'URN\')].value\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(121,0,1628486790,1,'BE',1,0,18,'tx_dlf_metadataformat','{\"uid\":18,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:publicationStmt\\/teihdr:idno[@type=\\\"urn\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(122,0,1628486790,1,'BE',1,0,19,'tx_dlf_metadataformat','{\"uid\":19,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:identifier[@type=\\\"urn\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(123,0,1628486790,1,'BE',1,0,20,'tx_dlf_metadataformat','{\"uid\":20,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:publicationStmt\\/teihdr:idno[@type=\\\"purl\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(124,0,1628486790,1,'BE',1,0,21,'tx_dlf_metadataformat','{\"uid\":21,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:identifier[@type=\\\"purl\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(125,0,1628486790,1,'BE',1,0,22,'tx_dlf_metadataformat','{\"uid\":22,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$.metadata.[?(@.label==\'Owner\')].value\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(126,0,1628486790,1,'BE',1,0,23,'tx_dlf_metadataformat','{\"uid\":23,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:publicationStmt\\/teihdr:publisher\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(127,0,1628486790,1,'BE',1,0,24,'tx_dlf_metadataformat','{\"uid\":24,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:name[.\\/mods:role\\/mods:roleTerm=\\\"own\\\"]\\/mods:displayForm\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(128,0,1628486790,1,'BE',1,0,25,'tx_dlf_metadataformat','{\"uid\":25,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$.metadata.[?(@.label==\'Collection\')].value\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(129,0,1628486790,1,'BE',1,0,26,'tx_dlf_metadataformat','{\"uid\":26,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:sourceDesc\\/teihdr:msDesc\\/teihdr:msIdentifier\\/teihdr:collection\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(130,0,1628486790,1,'BE',1,0,27,'tx_dlf_metadataformat','{\"uid\":27,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:classification\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(131,0,1628486790,1,'BE',1,0,28,'tx_dlf_metadataformat','{\"uid\":28,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:language\\/mods:languageTerm\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(132,0,1628486790,1,'BE',1,0,29,'tx_dlf_metadataformat','{\"uid\":29,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$.metadata.[?(@.label==\'Date of publication\')].value\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(133,0,1628486790,1,'BE',1,0,30,'tx_dlf_metadataformat','{\"uid\":30,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:sourceDesc\\/teihdr:msDesc\\/teihdr:head\\/teihdr:origDate\",\"xpath_sorting\":\".\\/teihdr:fileDesc\\/teihdr:sourceDesc\\/teihdr:msDesc\\/teihdr:head\\/teihdr:origDate\\/@when\",\"mandatory\":0}',0),(134,0,1628486790,1,'BE',1,0,31,'tx_dlf_metadataformat','{\"uid\":31,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$.metadata.[?(@.label==\'Place of publication\')].value\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(135,0,1628486790,1,'BE',1,0,32,'tx_dlf_metadataformat','{\"uid\":32,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:sourceDesc\\/teihdr:msDesc\\/teihdr:head\\/teihdr:origPlace\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(136,0,1628486790,1,'BE',1,0,33,'tx_dlf_metadataformat','{\"uid\":33,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$.metadata.[?(@.label==\'Author\')].value\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(137,0,1628486790,1,'BE',1,0,34,'tx_dlf_metadataformat','{\"uid\":34,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:sourceDesc\\/teihdr:msDesc\\/teihdr:head\\/teihdr:name\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(138,0,1628486790,1,'BE',1,0,35,'tx_dlf_metadataformat','{\"uid\":35,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\".\\/mods:part\\/mods:detail\\/mods:number\",\"xpath_sorting\":\".\\/mods:part[@type=\\\"host\\\"]\\/@order\",\"mandatory\":0}',0),(139,0,1628486790,1,'BE',1,0,36,'tx_dlf_metadataformat','{\"uid\":36,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$[label]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(140,0,1628486790,1,'BE',1,0,37,'tx_dlf_metadataformat','{\"uid\":37,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":2,\"xpath\":\".\\/teihdr:fileDesc\\/teihdr:sourceDesc\\/teihdr:msDesc\\/teihdr:head\\/teihdr:note[@type=\\\"caption\\\"]\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(141,0,1628486790,1,'BE',1,0,38,'tx_dlf_metadataformat','{\"uid\":38,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":1,\"xpath\":\"concat(.\\/mods:titleInfo\\/mods:nonSort,\\\" \\\",.\\/mods:titleInfo\\/mods:title)\",\"xpath_sorting\":\".\\/mods:titleInfo\\/mods:title\",\"mandatory\":0}',0),(142,0,1628486790,1,'BE',1,0,39,'tx_dlf_metadataformat','{\"uid\":39,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"parent_id\":0,\"encoded\":5,\"xpath\":\"$.metadata.[?(@.label==\'Manifest Type\')].value\",\"xpath_sorting\":\"\",\"mandatory\":0}',0),(143,0,1628486790,1,'BE',1,0,1,'tx_dlf_metadata','{\"uid\":1,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":256,\"l10n_state\":null,\"label\":\"Rights Information\",\"index_name\":\"rights_info\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":0,\"index_boost\":0,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(144,0,1628486790,1,'BE',1,0,2,'tx_dlf_metadata','{\"uid\":2,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":128,\"l10n_state\":null,\"label\":\"Out Of Print Works\",\"index_name\":\"out_of_print\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":1,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(145,0,1628486790,1,'BE',1,0,3,'tx_dlf_metadata','{\"uid\":3,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":64,\"l10n_state\":null,\"label\":\"Restrictions on Access\",\"index_name\":\"restrictions\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":1,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(146,0,1628486790,1,'BE',1,0,4,'tx_dlf_metadata','{\"uid\":4,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":32,\"l10n_state\":null,\"label\":\"Terms of Use\",\"index_name\":\"terms\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":1,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":1,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(147,0,1628486790,1,'BE',1,0,5,'tx_dlf_metadata','{\"uid\":5,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":16,\"l10n_state\":null,\"label\":\"License\",\"index_name\":\"license\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":1,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":1,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(148,0,1628486790,1,'BE',1,0,6,'tx_dlf_metadata','{\"uid\":6,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":8,\"l10n_state\":null,\"label\":\"Coordinates\",\"index_name\":\"coordinates\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":1,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(149,0,1628486790,1,'BE',1,0,7,'tx_dlf_metadata','{\"uid\":7,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":4,\"l10n_state\":null,\"label\":\"Kitodo Process Number\",\"index_name\":\"prod_id\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":0,\"index_boost\":0,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(150,0,1628486790,1,'BE',1,0,8,'tx_dlf_metadata','{\"uid\":8,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":2,\"l10n_state\":null,\"label\":\"OAI Identifier\",\"index_name\":\"record_id\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(151,0,1628486790,1,'BE',1,0,9,'tx_dlf_metadata','{\"uid\":9,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":1,\"l10n_state\":null,\"label\":\"Union Catalog ID\",\"index_name\":\"union_id\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(152,0,1628486790,1,'BE',1,0,10,'tx_dlf_metadata','{\"uid\":10,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":0,\"l10n_state\":null,\"label\":\"OPAC Identifier\",\"index_name\":\"opac_id\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(153,0,1628486790,1,'BE',1,0,11,'tx_dlf_metadata','{\"uid\":11,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":256,\"l10n_state\":null,\"label\":\"URN\",\"index_name\":\"urn\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.setContentToCurrent = 1\\nvalue.typolink.parameter.current = 1\\nvalue.typolink.parameter.prepend = TEXT\\nvalue.typolink.parameter.prepend.value = http:\\/\\/nbn-resolving.de\\/\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(154,0,1628486790,1,'BE',1,0,12,'tx_dlf_metadata','{\"uid\":12,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":128,\"l10n_state\":null,\"label\":\"PURL\",\"index_name\":\"purl\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.setContentToCurrent = 1\\nvalue.typolink.parameter.current = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":0,\"index_boost\":0,\"is_sortable\":0,\"is_facet\":0,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(155,0,1628486790,1,'BE',1,0,13,'tx_dlf_metadata','{\"uid\":13,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":64,\"l10n_state\":null,\"label\":\"Owner\",\"index_name\":\"owner\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":1,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(156,0,1628486790,1,'BE',1,0,14,'tx_dlf_metadata','{\"uid\":14,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":32,\"l10n_state\":null,\"label\":\"Collection(s)\",\"index_name\":\"collection\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":1,\"index_stored\":0,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":1,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(157,0,1628486790,1,'BE',1,0,15,'tx_dlf_metadata','{\"uid\":15,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":16,\"l10n_state\":null,\"label\":\"Language\",\"index_name\":\"language\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":0,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":0,\"is_facet\":1,\"is_listed\":0,\"index_autocomplete\":0,\"status\":0}',0),(158,0,1628486790,1,'BE',1,0,16,'tx_dlf_metadata','{\"uid\":16,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":8,\"l10n_state\":null,\"label\":\"Year of Publication\",\"index_name\":\"year\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":1,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":1,\"is_facet\":1,\"is_listed\":1,\"index_autocomplete\":0,\"status\":0}',0),(159,0,1628486790,1,'BE',1,0,17,'tx_dlf_metadata','{\"uid\":17,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":4,\"l10n_state\":null,\"label\":\"Place of Publication\",\"index_name\":\"place\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":1,\"index_stored\":1,\"index_indexed\":1,\"index_boost\":1,\"is_sortable\":1,\"is_facet\":1,\"is_listed\":1,\"index_autocomplete\":0,\"status\":0}',0),(160,0,1628486790,1,'BE',1,0,18,'tx_dlf_metadata','{\"uid\":18,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":2,\"l10n_state\":null,\"label\":\"Author\",\"index_name\":\"author\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt class=\\\"tx-dlf-metadata-author\\\">|<\\/dt>\\nvalue.required = 1\\nvalue.split.token.char = 31\\nvalue.split.cObjNum = 1\\nvalue.split.1.1 = CASE\\nvalue.split.1.1.key.data = register:SPLIT_COUNT\\nvalue.split.1.1.0 = LOAD_REGISTER\\nvalue.split.1.1.0.tx_dlf_metadata_author_name.current = 1\\nvalue.split.1.1.1 = LOAD_REGISTER\\nvalue.split.1.1.1.tx_dlf_metadata_author_uri.current = 1\\nvalue.postCObject = TEXT\\nvalue.postCObject.value = {register:tx_dlf_metadata_author_name}\\nvalue.postCObject.value.insertData = 1\\nvalue.postCObject.value.stdWrap.typolink.parameter = {register:tx_dlf_metadata_author_uri} _blank external\\nvalue.postCObject.value.stdWrap.typolink.parameter.insertData = 1\\nvalue.postCObject.value.stdWrap.typolink.title = {register:tx_dlf_metadata_author_name}\\nvalue.postCObject.value.stdWrap.typolink.ifNotEmpty = 1\\nvalue.wrap = <dd class=\\\"tx-dlf-metadata-author\\\">|<\\/dd>\",\"index_tokenized\":1,\"index_stored\":1,\"index_indexed\":1,\"index_boost\":2,\"is_sortable\":1,\"is_facet\":1,\"is_listed\":1,\"index_autocomplete\":1,\"status\":0}',0),(161,0,1628486790,1,'BE',1,0,19,'tx_dlf_metadata','{\"uid\":19,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":1,\"l10n_state\":null,\"label\":\"Volume\",\"index_name\":\"volume\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":1,\"index_indexed\":0,\"index_boost\":1,\"is_sortable\":1,\"is_facet\":0,\"is_listed\":1,\"index_autocomplete\":0,\"status\":0}',0),(162,0,1628486790,1,'BE',1,0,20,'tx_dlf_metadata','{\"uid\":20,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":0,\"l10n_state\":null,\"label\":\"Title\",\"index_name\":\"title\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt class=\\\"tx-dlf-metadata-title\\\">|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd class=\\\"tx-dlf-metadata-title\\\">|<\\/dd>\",\"index_tokenized\":1,\"index_stored\":1,\"index_indexed\":1,\"index_boost\":2,\"is_sortable\":1,\"is_facet\":0,\"is_listed\":1,\"index_autocomplete\":1,\"status\":0}',0),(163,0,1628486790,1,'BE',1,0,21,'tx_dlf_metadata','{\"uid\":21,\"pid\":2,\"tstamp\":1628486790,\"crdate\":1628486790,\"cruser_id\":1,\"deleted\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"a:14:{s:5:\\\"label\\\";N;s:10:\\\"index_name\\\";N;s:6:\\\"format\\\";N;s:13:\\\"default_value\\\";N;s:4:\\\"wrap\\\";N;s:15:\\\"index_tokenized\\\";N;s:12:\\\"index_stored\\\";N;s:13:\\\"index_indexed\\\";N;s:11:\\\"index_boost\\\";N;s:11:\\\"is_sortable\\\";N;s:8:\\\"is_facet\\\";N;s:9:\\\"is_listed\\\";N;s:18:\\\"index_autocomplete\\\";N;s:16:\\\"sys_language_uid\\\";N;}\",\"hidden\":0,\"sorting\":256,\"l10n_state\":null,\"label\":\"Type\",\"index_name\":\"type\",\"format\":0,\"default_value\":\"\",\"wrap\":\"key.wrap = <dt>|<\\/dt>\\nvalue.required = 1\\nvalue.wrap = <dd>|<\\/dd>\",\"index_tokenized\":0,\"index_stored\":1,\"index_indexed\":0,\"index_boost\":1,\"is_sortable\":1,\"is_facet\":1,\"is_listed\":1,\"index_autocomplete\":0,\"status\":0}',0),(164,0,1628487239,1,'BE',1,0,1,'sys_language','{\"uid\":1,\"pid\":0,\"tstamp\":1628487239,\"hidden\":0,\"sorting\":256,\"title\":\"English\",\"flag\":\"us\",\"language_isocode\":\"en\",\"static_lang_isocode\":0}',0),(165,0,1628488695,1,'BE',1,0,1,'sys_template','{\"uid\":1,\"pid\":1,\"tstamp\":1628488695,\"crdate\":1628488695,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"title\":\"NEW SITE\",\"sitetitle\":\"\",\"root\":1,\"clear\":3,\"include_static_file\":null,\"constants\":null,\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"nextLevel\":\"\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0),(166,0,1628488724,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"title\":\"NEW SITE\"},\"newRecord\":{\"title\":\"Viewer\"}}',0),(167,0,1628488854,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":null,\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"include_static_file\":null},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\r\\n}\",\"config\":\"# Default PAGE object:\\r\\npage = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = HELLO WORLD!\\r\\n\",\"include_static_file\":\"EXT:dlf\\/Configuration\\/TypoScript\\/TableOfContents\\/,EXT:dlf\\/Configuration\\/TypoScript\\/Toolbox\\/,EXT:ddb_kitodo_zeitungsportal\\/Configuration\\/TypoScript\"}}',0),(168,0,1628489093,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\r\\n}\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  #baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\r\\n  baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"}}',0),(169,0,1628508786,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"# Default PAGE object:\\r\\npage = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = HELLO WORLD!\\r\\n\"},\"newRecord\":{\"config\":\"# Default PAGE object:\\r\\n\\r\\n\"}}',0),(170,0,1628768475,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  #baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\r\\n  baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"}}',0),(171,0,1628833686,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"}}',0),(172,0,1628837141,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"}}',0),(173,0,1628837146,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"}}',0),(174,0,1629118724,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"# Default PAGE object:\\r\\n\\r\\n\"},\"newRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\"}}',0),(175,0,1629119531,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\"},\"newRecord\":{\"config\":\"#plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\"}}',0),(176,0,1629120019,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"#plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\"},\"newRecord\":{\"config\":\"\"}}',0),(177,0,1629120437,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\"},\"newRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\"}}',0),(178,0,1629180334,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\"},\"newRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\nplugin.tx_dlf_searchindocumenttool.searchUrl = http:\\/\\/localhost:8080\\/ddb-next\\/newspaper\\/item\"}}',0),(179,0,1629180466,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\nplugin.tx_dlf_searchindocumenttool.searchUrl = http:\\/\\/localhost:8080\\/ddb-next\\/newspaper\\/item\"},\"newRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\nplugin.tx_dlf_searchindocumenttool.searchUrl = http:\\/\\/localhost:8080\\/ddb-next\\/newspaper\\/item\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\"}}',0),(180,0,1629184457,2,'BE',3,0,3,'be_users','{\"oldRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$MEZkZi56YmgvUndVM3Yvaw$Q74UsIgbLH5fHdWJQErdsDnl+Z8vJuTbC0iG02MbLOQ\"},\"newRecord\":{\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$Y2dOZ0hnNUIvUnlxUjlVRg$hwsrFkUiggAx7NXrnTqHQKeMaJZaRtPFVmjiN2w0A44\"}}',0),(181,0,1629184744,3,'BE',3,0,2,'pages','{\"oldPageId\":0,\"newPageId\":1,\"oldData\":{\"header\":\"Kitodo Konfiguration\",\"pid\":0,\"event_pid\":2,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1629184744,\"pid\":1,\"sorting\":256}}',0),(182,0,1629184863,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  #baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  baseUrl = https:\\/\\/ddev-ddb-zeitungsportal.ddev.site\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"}}',0),(183,0,1629185218,2,'BE',3,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"no_search\":0,\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"no_search\":\"1\",\"l10n_diffsource\":\"a:47:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:9:\\\"seo_title\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:11:\\\"description\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(184,0,1629188462,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  #baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  baseUrl = https:\\/\\/ddev-ddb-zeitungsportal.ddev.site\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\",\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\nplugin.tx_dlf_searchindocumenttool.searchUrl = http:\\/\\/localhost:8080\\/ddb-next\\/newspaper\\/item\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  #baseUrl = https:\\/\\/ddev-ddb-zeitungsportal.ddev.site\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\",\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = http:\\/\\/localhost:8080\\/ddb-next\\/newspaper\\/item\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\"}}',0),(185,0,1629189447,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  #baseUrl = https:\\/\\/ddev-ddb-zeitungsportal.ddev.site\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  #baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  baseUrl = https:\\/\\/ddev-ddb-zeitungsportal.ddev.site\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"}}',0),(186,0,1630422828,1,'BE',3,0,3,'pages','{\"uid\":3,\"pid\":0,\"tstamp\":1630422828,\"crdate\":1630422828,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":1,\"l10n_parent\":1,\"l10n_source\":1,\"l10n_state\":\"{\\\"starttime\\\":\\\"parent\\\",\\\"endtime\\\":\\\"parent\\\",\\\"nav_hide\\\":\\\"parent\\\",\\\"url\\\":\\\"parent\\\",\\\"lastUpdated\\\":\\\"parent\\\",\\\"newUntil\\\":\\\"parent\\\",\\\"no_search\\\":\\\"parent\\\",\\\"shortcut\\\":\\\"parent\\\",\\\"shortcut_mode\\\":\\\"parent\\\",\\\"content_from_pid\\\":\\\"parent\\\",\\\"author\\\":\\\"parent\\\",\\\"author_email\\\":\\\"parent\\\",\\\"media\\\":\\\"parent\\\",\\\"og_image\\\":\\\"parent\\\",\\\"twitter_image\\\":\\\"parent\\\"}\",\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"[Translate to English:] Viewer\",\"slug\":\"\\/\",\"doktype\":1,\"TSconfig\":\"\",\"is_siteroot\":1,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":1,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"alias\":\"\",\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"canonical_link\":\"\",\"categories\":0}',0),(187,0,1630422831,2,'BE',3,0,3,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:38:{s:7:\\\"doktype\\\";i:1;s:5:\\\"title\\\";s:6:\\\"Viewer\\\";s:4:\\\"slug\\\";s:1:\\\"\\/\\\";s:9:\\\"nav_title\\\";s:0:\\\"\\\";s:8:\\\"subtitle\\\";s:0:\\\"\\\";s:9:\\\"seo_title\\\";s:0:\\\"\\\";s:14:\\\"canonical_link\\\";s:0:\\\"\\\";s:8:\\\"og_title\\\";s:0:\\\"\\\";s:14:\\\"og_description\\\";s:0:\\\"\\\";s:13:\\\"twitter_title\\\";s:0:\\\"\\\";s:19:\\\"twitter_description\\\";s:0:\\\"\\\";s:8:\\\"abstract\\\";s:0:\\\"\\\";s:8:\\\"keywords\\\";s:0:\\\"\\\";s:11:\\\"description\\\";s:0:\\\"\\\";s:6:\\\"hidden\\\";i:0;s:10:\\\"categories\\\";i:0;s:14:\\\"rowDescription\\\";s:0:\\\"\\\";s:8:\\\"TSconfig\\\";s:0:\\\"\\\";s:13:\\\"php_tree_stop\\\";i:0;s:8:\\\"editlock\\\";i:0;s:6:\\\"layout\\\";i:0;s:8:\\\"fe_group\\\";s:0:\\\"\\\";s:16:\\\"extendToSubpages\\\";i:0;s:6:\\\"target\\\";s:0:\\\"\\\";s:5:\\\"alias\\\";s:0:\\\"\\\";s:13:\\\"cache_timeout\\\";i:0;s:10:\\\"cache_tags\\\";s:0:\\\"\\\";s:9:\\\"mount_pid\\\";i:0;s:11:\\\"is_siteroot\\\";i:1;s:12:\\\"mount_pid_ol\\\";i:0;s:6:\\\"module\\\";s:0:\\\"\\\";s:13:\\\"fe_login_mode\\\";i:0;s:8:\\\"l18n_cfg\\\";i:0;s:14:\\\"backend_layout\\\";s:0:\\\"\\\";s:25:\\\"backend_layout_next_level\\\";s:0:\\\"\\\";s:17:\\\"tsconfig_includes\\\";s:0:\\\"\\\";s:8:\\\"no_index\\\";i:0;s:9:\\\"no_follow\\\";i:0;}\"}}',0),(188,0,1630492911,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = http:\\/\\/localhost:8080\\/ddb-next\\/newspaper\\/item\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\"},\"newRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = http:\\/\\/localhost:8080\\/ddb-next\\/newspaper\\/item\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\n\\r\\nconfig.forceAbsoluteUrlHttps = 1\"}}',0),(189,0,1630500948,1,'BE',3,0,4,'pages','{\"uid\":4,\"pid\":0,\"tstamp\":1630500948,\"crdate\":1630500948,\"cruser_id\":3,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":512,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_id\":0,\"t3ver_label\":\"\",\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Viewerdev\",\"slug\":\"\\/\",\"doktype\":1,\"TSconfig\":\"\",\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":\"\",\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":\"\",\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":\"\",\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"alias\":\"\",\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":\"\",\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":0,\"canonical_link\":\"\",\"categories\":0}',0),(190,0,1630500951,3,'BE',3,0,4,'pages','{\"oldPageId\":0,\"newPageId\":1,\"oldData\":{\"header\":\"Viewerdev\",\"pid\":0,\"event_pid\":4,\"t3ver_state\":0,\"_ORIG_pid\":null},\"newData\":{\"tstamp\":1630500951,\"pid\":1,\"sorting\":128}}',0),(191,0,1630500958,2,'BE',3,0,4,'pages','{\"oldRecord\":{\"slug\":\"\\/2\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"slug\":\"\\/viewerdev\",\"l10n_diffsource\":\"a:47:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:9:\\\"seo_title\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:11:\\\"description\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0),(192,0,1630500985,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 1\\r\\n  #page url on which viewer will be visible\\r\\n  #baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  baseUrl = https:\\/\\/ddev-ddb-zeitungsportal.ddev.site\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"},\"newRecord\":{\"constants\":\"constant {\\r\\n  # id of configuration directory (Kitodo Konfiguration)\\r\\n  configPid = 2\\r\\n  # id of Viewer page\\r\\n  viewerPid = 4\\r\\n  #page url on which viewer will be visible\\r\\n  #baseUrl = https:\\/\\/viewer-dzp.deutsche-digitale-bibliothek.de\\/\\r\\n  baseUrl = https:\\/\\/ddev-ddb-zeitungsportal.ddev.site\\/\\r\\n  #baseUrl = http:\\/\\/ddb-p2-vmzpviewer01:8001\\/zp-viewer\\r\\n}\"}}',0),(193,0,1631137606,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = http:\\/\\/localhost:8080\\/ddb-next\\/newspaper\\/item\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\n\\r\\nconfig.forceAbsoluteUrlHttps = 1\"},\"newRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\n\\r\\n\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\nplugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/api-q1.deutsche-digitale-bibliothek.de\\/items\\/*id*\\/source\\/record\"}}',0),(194,0,1631137842,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"config\":\"plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\n\\r\\n\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\nplugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/api-q1.deutsche-digitale-bibliothek.de\\/items\\/*id*\\/source\\/record\"},\"newRecord\":{\"config\":\"# dev\\r\\nplugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\n\\r\\n# master\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\nplugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/api-q1.deutsche-digitale-bibliothek.de\\/items\\/*id*\\/source\\/record\\r\\n\\r\\n\"}}',0),(195,0,1631137866,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:dlf\\/Configuration\\/TypoScript\\/TableOfContents\\/,EXT:dlf\\/Configuration\\/TypoScript\\/Toolbox\\/,EXT:ddb_kitodo_zeitungsportal\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:dlf\\/Configuration\\/TypoScript\\/TableOfContents\\/,EXT:dlf\\/Configuration\\/TypoScript\\/Toolbox\\/\"}}',0),(196,0,1631137883,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:dlf\\/Configuration\\/TypoScript\\/TableOfContents\\/,EXT:dlf\\/Configuration\\/TypoScript\\/Toolbox\\/\"},\"newRecord\":{\"include_static_file\":\"EXT:dlf\\/Configuration\\/TypoScript\\/TableOfContents\\/,EXT:dlf\\/Configuration\\/TypoScript\\/Toolbox\\/,EXT:ddb_kitodo_zeitungsportal\\/Configuration\\/TypoScript\"}}',0),(197,0,1632299231,2,'BE',3,0,4,'pages','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":\"a:47:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:9:\\\"seo_title\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:11:\\\"description\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0),(198,0,1632299811,2,'BE',3,0,1,'sys_template','{\"oldRecord\":{\"config\":\"# dev\\r\\nplugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\n\\r\\n# master\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\nplugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/api-q1.deutsche-digitale-bibliothek.de\\/items\\/*id*\\/source\\/record\\r\\n\\r\\n\"},\"newRecord\":{\"config\":\"# dev\\r\\nplugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/api\\/items\\/*id*\\/source\\/record\\r\\nplugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\n\\r\\n# master\\r\\n#plugin.tx_dlf_searchindocumenttool.searchUrl = https:\\/\\/dev-ddb.fiz-karlsruhe.de\\/ddb-current\\/newspaper\\/item\\r\\n#plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https:\\/\\/api-q1.deutsche-digitale-bibliothek.de\\/items\\/*id*\\/source\\/record\\r\\n\\r\\n\"}}',0);
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language_isocode` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `static_lang_isocode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
INSERT INTO `sys_language` VALUES (1,0,1628487239,0,256,'English','us','en',0);
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (34,1,1629120724,'sys_template',1,0,'kitodo',0),(74,3,1632299811,'sys_template',1,0,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `log_data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `request_id` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `level` smallint(5) unsigned NOT NULL DEFAULT 0,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=393 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,0,1628075375,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(2,0,1628075905,1,2,1,'be_users',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"kitodo\";i:1;s:10:\"be_users:1\";s:7:\"history\";s:1:\"1\";}',0,0,'','',0,'',0,NULL,NULL),(3,0,1628164587,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1301648975: No pages are found on the rootlevel! | TYPO3\\CMS\\Core\\Error\\Http\\ServiceUnavailableException thrown in file /data/www/public/typo3/sysext/frontend/Classes/Controller/TypoScriptFrontendController.php in line 1445. Requested URL: http://ddb-p2-vmzpviewer01:8001/',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(4,0,1628164620,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(5,0,1628164637,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!!',255,2,'141.66.6.77','a:1:{i:0;s:16:\"ktiodo@localhost\";}',-1,-99,'','',0,'',0,NULL,NULL),(6,0,1628164678,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(7,0,1628166052,1,1,1,'tx_dlf_formats',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:16:\"tx_dlf_formats:1\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW610bd7a5164e7','',0,'',0,NULL,NULL),(8,0,1628166052,1,1,2,'tx_dlf_formats',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:16:\"tx_dlf_formats:2\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW610bd7a5164e9','',0,'',0,NULL,NULL),(9,0,1628166052,1,1,3,'tx_dlf_formats',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"ALTO\";i:1;s:16:\"tx_dlf_formats:3\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW610bd7a5164ea','',0,'',0,NULL,NULL),(10,0,1628166052,1,1,4,'tx_dlf_formats',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF1\";i:1;s:16:\"tx_dlf_formats:4\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW610bd7a5164eb','',0,'',0,NULL,NULL),(11,0,1628166052,1,1,5,'tx_dlf_formats',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:16:\"tx_dlf_formats:5\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW610bd7a5164ec','',0,'',0,NULL,NULL),(12,0,1628166052,1,1,6,'tx_dlf_formats',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF3\";i:1;s:16:\"tx_dlf_formats:6\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW610bd7a5164ed','',0,'',0,NULL,NULL),(13,0,1628166052,1,0,0,'',0,1,'Core: Error handler (BE): PHP Warning: count(): Parameter must be an array or an object that implements Countable in /data/www/vendor/solarium/solarium/src/Core/Client/Adapter/Http.php line 54',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(14,0,1628166633,1,1,1,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Viewer\";i:1;s:7:\"pages:1\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW610bd9c2e968c689176172','',0,'',0,NULL,NULL),(15,0,1628166682,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1294587218: No TypoScript template found! | TYPO3\\CMS\\Core\\Error\\Http\\ServiceUnavailableException thrown in file /data/www/public/typo3/sysext/frontend/Classes/Controller/TypoScriptFrontendController.php in line 2688. Requested URL: http://ddb-p2-vmzpviewer01:8001/index.php?id=1&no_cache=1',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(16,0,1628166800,1,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:7:\"pages:1\";s:7:\"history\";s:1:\"9\";}',1,0,'','',0,'',0,NULL,NULL),(17,0,1628236837,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(18,0,1628237034,1,0,0,'',0,1,'Core: Error handler (BE): PHP Warning: unlink(/data/www/var/cache/code/cache_core/site-configuration.php): No such file or directory in /data/www/public/typo3/sysext/core/Classes/Cache/Backend/SimpleFileBackend.php line 291',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(19,0,1628250488,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(20,0,1628486051,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(21,0,1628486511,1,1,2,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:20:\"Kitodo Konfiguration\";i:1;s:7:\"pages:2\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW_1','',0,'',0,NULL,NULL),(22,0,1628486525,1,2,2,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:20:\"Kitodo Konfiguration\";i:1;s:7:\"pages:2\";s:7:\"history\";s:2:\"11\";}',2,0,'','',0,'',0,NULL,NULL),(23,0,1628486528,1,2,2,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:20:\"Kitodo Konfiguration\";i:1;s:7:\"pages:2\";s:7:\"history\";s:2:\"12\";}',2,0,'','',0,'',0,NULL,NULL),(24,0,1628486788,1,1,1,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"Year\";i:1;s:19:\"tx_dlf_structures:1\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479286','',0,'',0,NULL,NULL),(25,0,1628486788,1,1,2,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Volume\";i:1;s:19:\"tx_dlf_structures:2\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479285','',0,'',0,NULL,NULL),(26,0,1628486788,1,1,3,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Verse\";i:1;s:19:\"tx_dlf_structures:3\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479284','',0,'',0,NULL,NULL),(27,0,1628486788,1,1,4,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:9:\"Titlepage\";i:1;s:19:\"tx_dlf_structures:4\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479283','',0,'',0,NULL,NULL),(28,0,1628486788,1,1,5,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"Text\";i:1;s:19:\"tx_dlf_structures:5\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479282','',0,'',0,NULL,NULL),(29,0,1628486788,1,1,6,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Table\";i:1;s:19:\"tx_dlf_structures:6\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479281','',0,'',0,NULL,NULL),(30,0,1628486788,1,1,7,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:12:\"Subinventory\";i:1;s:19:\"tx_dlf_structures:7\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479280','',0,'',0,NULL,NULL),(31,0,1628486788,1,1,8,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Study\";i:1;s:19:\"tx_dlf_structures:8\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847927f','',0,'',0,NULL,NULL),(32,0,1628486788,1,1,9,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Stamp\";i:1;s:19:\"tx_dlf_structures:9\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847927e','',0,'',0,NULL,NULL),(33,0,1628486788,1,1,10,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Spine\";i:1;s:20:\"tx_dlf_structures:10\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847927d','',0,'',0,NULL,NULL),(34,0,1628486788,1,1,11,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Section\";i:1;s:20:\"tx_dlf_structures:11\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847927c','',0,'',0,NULL,NULL),(35,0,1628486788,1,1,12,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"Seal\";i:1;s:20:\"tx_dlf_structures:12\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847927b','',0,'',0,NULL,NULL),(36,0,1628486788,1,1,13,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Scheme\";i:1;s:20:\"tx_dlf_structures:13\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847927a','',0,'',0,NULL,NULL),(37,0,1628486788,1,1,14,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:14:\"Research Paper\";i:1;s:20:\"tx_dlf_structures:14\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479278','',0,'',0,NULL,NULL),(38,0,1628486788,1,1,15,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Report\";i:1;s:20:\"tx_dlf_structures:15\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847926c','',0,'',0,NULL,NULL),(39,0,1628486788,1,1,16,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Register\";i:1;s:20:\"tx_dlf_structures:16\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847926b','',0,'',0,NULL,NULL),(40,0,1628486788,1,1,17,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Provenance\";i:1;s:20:\"tx_dlf_structures:17\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847926a','',0,'',0,NULL,NULL),(41,0,1628486788,1,1,18,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Proceeding\";i:1;s:20:\"tx_dlf_structures:18\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479269','',0,'',0,NULL,NULL),(42,0,1628486788,1,1,19,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Privileges\";i:1;s:20:\"tx_dlf_structures:19\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479268','',0,'',0,NULL,NULL),(43,0,1628486788,1,1,20,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:13:\"Printers Mark\";i:1;s:20:\"tx_dlf_structures:20\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479267','',0,'',0,NULL,NULL),(44,0,1628486788,1,1,21,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:16:\"Printed Archives\";i:1;s:20:\"tx_dlf_structures:21\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479266','',0,'',0,NULL,NULL),(45,0,1628486788,1,1,22,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Preprint\";i:1;s:20:\"tx_dlf_structures:22\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479265','',0,'',0,NULL,NULL),(46,0,1628486788,1,1,23,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Preface\";i:1;s:20:\"tx_dlf_structures:23\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479264','',0,'',0,NULL,NULL),(47,0,1628486788,1,1,24,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Poster\";i:1;s:20:\"tx_dlf_structures:24\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479263','',0,'',0,NULL,NULL),(48,0,1628486788,1,1,25,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"Plan\";i:1;s:20:\"tx_dlf_structures:25\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479262','',0,'',0,NULL,NULL),(49,0,1628486788,1,1,26,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Photograph\";i:1;s:20:\"tx_dlf_structures:26\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479261','',0,'',0,NULL,NULL),(50,0,1628486788,1,1,27,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Periodical\";i:1;s:20:\"tx_dlf_structures:27\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479260','',0,'',0,NULL,NULL),(51,0,1628486788,1,1,28,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Paste Down\";i:1;s:20:\"tx_dlf_structures:28\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847925f','',0,'',0,NULL,NULL),(52,0,1628486788,1,1,29,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Paper\";i:1;s:20:\"tx_dlf_structures:29\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847925e','',0,'',0,NULL,NULL),(53,0,1628486788,1,1,30,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"Page\";i:1;s:20:\"tx_dlf_structures:30\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847925d','',0,'',0,NULL,NULL),(54,0,1628486788,1,1,31,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Ornament\";i:1;s:20:\"tx_dlf_structures:31\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847925c','',0,'',0,NULL,NULL),(55,0,1628486788,1,1,32,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:21:\"Official Notification\";i:1;s:20:\"tx_dlf_structures:32\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847925b','',0,'',0,NULL,NULL),(56,0,1628486788,1,1,33,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"Note\";i:1;s:20:\"tx_dlf_structures:33\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847925a','',0,'',0,NULL,NULL),(57,0,1628486788,1,1,34,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:9:\"Newspaper\";i:1;s:20:\"tx_dlf_structures:34\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479259','',0,'',0,NULL,NULL),(58,0,1628486788,1,1,35,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:16:\"Musical Notation\";i:1;s:20:\"tx_dlf_structures:35\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479258','',0,'',0,NULL,NULL),(59,0,1628486788,1,1,36,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:16:\"Multivolume Work\";i:1;s:20:\"tx_dlf_structures:36\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479257','',0,'',0,NULL,NULL),(60,0,1628486788,1,1,37,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Month\";i:1;s:20:\"tx_dlf_structures:37\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479256','',0,'',0,NULL,NULL),(61,0,1628486788,1,1,38,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:9:\"Monograph\";i:1;s:20:\"tx_dlf_structures:38\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479255','',0,'',0,NULL,NULL),(62,0,1628486788,1,1,39,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:3:\"Map\";i:1;s:20:\"tx_dlf_structures:39\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479254','',0,'',0,NULL,NULL),(63,0,1628486788,1,1,40,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Manuscript\";i:1;s:20:\"tx_dlf_structures:40\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479253','',0,'',0,NULL,NULL),(64,0,1628486788,1,1,41,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:13:\"Master Thesis\";i:1;s:20:\"tx_dlf_structures:41\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479252','',0,'',0,NULL,NULL),(65,0,1628486788,1,1,42,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:15:\"Magister Thesis\";i:1;s:20:\"tx_dlf_structures:42\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479251','',0,'',0,NULL,NULL),(66,0,1628486788,1,1,43,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Letter\";i:1;s:20:\"tx_dlf_structures:43\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479250','',0,'',0,NULL,NULL),(67,0,1628486788,1,1,44,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Lecture\";i:1;s:20:\"tx_dlf_structures:44\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847924f','',0,'',0,NULL,NULL),(68,0,1628486788,1,1,45,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Leaflet\";i:1;s:20:\"tx_dlf_structures:45\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847924e','',0,'',0,NULL,NULL),(69,0,1628486788,1,1,46,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:13:\"Land Register\";i:1;s:20:\"tx_dlf_structures:46\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847924d','',0,'',0,NULL,NULL),(70,0,1628486788,1,1,47,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:9:\"Judgement\";i:1;s:20:\"tx_dlf_structures:47\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847924c','',0,'',0,NULL,NULL),(71,0,1628486788,1,1,48,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Issue\";i:1;s:20:\"tx_dlf_structures:48\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847924b','',0,'',0,NULL,NULL),(72,0,1628486788,1,1,49,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:9:\"Inventory\";i:1;s:20:\"tx_dlf_structures:49\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847924a','',0,'',0,NULL,NULL),(73,0,1628486788,1,1,50,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:18:\"Initial Decoration\";i:1;s:20:\"tx_dlf_structures:50\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479249','',0,'',0,NULL,NULL),(74,0,1628486788,1,1,51,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Index\";i:1;s:20:\"tx_dlf_structures:51\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479248','',0,'',0,NULL,NULL),(75,0,1628486788,1,1,52,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Imprint\";i:1;s:20:\"tx_dlf_structures:52\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479247','',0,'',0,NULL,NULL),(76,0,1628486788,1,1,53,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Image\";i:1;s:20:\"tx_dlf_structures:53\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479246','',0,'',0,NULL,NULL),(77,0,1628486788,1,1,54,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:12:\"Illustration\";i:1;s:20:\"tx_dlf_structures:54\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479245','',0,'',0,NULL,NULL),(78,0,1628486788,1,1,55,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:19:\"Habilitation Thesis\";i:1;s:20:\"tx_dlf_structures:55\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479244','',0,'',0,NULL,NULL),(79,0,1628486788,1,1,56,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:11:\"Ground Plan\";i:1;s:20:\"tx_dlf_structures:56\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479243','',0,'',0,NULL,NULL),(80,0,1628486788,1,1,57,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Fragment\";i:1;s:20:\"tx_dlf_structures:57\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479242','',0,'',0,NULL,NULL),(81,0,1628486788,1,1,58,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Folder\";i:1;s:20:\"tx_dlf_structures:58\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479241','',0,'',0,NULL,NULL),(82,0,1628486788,1,1,59,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"File\";i:1;s:20:\"tx_dlf_structures:59\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479240','',0,'',0,NULL,NULL),(83,0,1628486788,1,1,60,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Fascicle\";i:1;s:20:\"tx_dlf_structures:60\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847923f','',0,'',0,NULL,NULL),(84,0,1628486788,1,1,61,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Ephemera\";i:1;s:20:\"tx_dlf_structures:61\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847923e','',0,'',0,NULL,NULL),(85,0,1628486788,1,1,62,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Entry\";i:1;s:20:\"tx_dlf_structures:62\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847923d','',0,'',0,NULL,NULL),(86,0,1628486788,1,1,63,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:18:\"Engraved Titlepage\";i:1;s:20:\"tx_dlf_structures:63\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847923c','',0,'',0,NULL,NULL),(87,0,1628486788,1,1,64,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Endsheet\";i:1;s:20:\"tx_dlf_structures:64\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847923b','',0,'',0,NULL,NULL),(88,0,1628486788,1,1,65,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"Edge\";i:1;s:20:\"tx_dlf_structures:65\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847923a','',0,'',0,NULL,NULL),(89,0,1628486788,1,1,66,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Dossier\";i:1;s:20:\"tx_dlf_structures:66\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479239','',0,'',0,NULL,NULL),(90,0,1628486788,1,1,67,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Document\";i:1;s:20:\"tx_dlf_structures:67\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479238','',0,'',0,NULL,NULL),(91,0,1628486788,1,1,68,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:15:\"Doctoral Thesis\";i:1;s:20:\"tx_dlf_structures:68\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479237','',0,'',0,NULL,NULL),(92,0,1628486788,1,1,69,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:14:\"Diploma Thesis\";i:1;s:20:\"tx_dlf_structures:69\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479236','',0,'',0,NULL,NULL),(93,0,1628486788,1,1,70,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Dedication\";i:1;s:20:\"tx_dlf_structures:70\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479235','',0,'',0,NULL,NULL),(94,0,1628486788,1,1,71,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:3:\"Day\";i:1;s:20:\"tx_dlf_structures:71\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479234','',0,'',0,NULL,NULL),(95,0,1628486788,1,1,72,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Back Cover\";i:1;s:20:\"tx_dlf_structures:72\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479233','',0,'',0,NULL,NULL),(96,0,1628486788,1,1,73,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:11:\"Front Cover\";i:1;s:20:\"tx_dlf_structures:73\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479232','',0,'',0,NULL,NULL),(97,0,1628486788,1,1,74,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Cover\";i:1;s:20:\"tx_dlf_structures:74\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479231','',0,'',0,NULL,NULL),(98,0,1628486788,1,1,75,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Corrigenda\";i:1;s:20:\"tx_dlf_structures:75\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479230','',0,'',0,NULL,NULL),(99,0,1628486788,1,1,76,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:17:\"Table of Contents\";i:1;s:20:\"tx_dlf_structures:76\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847922f','',0,'',0,NULL,NULL),(100,0,1628486788,1,1,77,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:14:\"Contained Work\";i:1;s:20:\"tx_dlf_structures:77\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847922e','',0,'',0,NULL,NULL),(101,0,1628486788,1,1,78,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Colophon\";i:1;s:20:\"tx_dlf_structures:78\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847922d','',0,'',0,NULL,NULL),(102,0,1628486788,1,1,79,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:9:\"Collation\";i:1;s:20:\"tx_dlf_structures:79\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847922c','',0,'',0,NULL,NULL),(103,0,1628486788,1,1,80,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Chapter\";i:1;s:20:\"tx_dlf_structures:80\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847922b','',0,'',0,NULL,NULL),(104,0,1628486788,1,1,81,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:9:\"Cartulary\";i:1;s:20:\"tx_dlf_structures:81\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc847922a','',0,'',0,NULL,NULL),(105,0,1628486788,1,1,82,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:9:\"Bookplate\";i:1;s:20:\"tx_dlf_structures:82\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479229','',0,'',0,NULL,NULL),(106,0,1628486788,1,1,83,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Binding\";i:1;s:20:\"tx_dlf_structures:83\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479228','',0,'',0,NULL,NULL),(107,0,1628486788,1,1,84,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:15:\"Bachelor Thesis\";i:1;s:20:\"tx_dlf_structures:84\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479227','',0,'',0,NULL,NULL),(108,0,1628486788,1,1,85,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Atlas\";i:1;s:20:\"tx_dlf_structures:85\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479226','',0,'',0,NULL,NULL),(109,0,1628486788,1,1,86,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Article\";i:1;s:20:\"tx_dlf_structures:86\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479225','',0,'',0,NULL,NULL),(110,0,1628486788,1,1,87,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Annotation\";i:1;s:20:\"tx_dlf_structures:87\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479224','',0,'',0,NULL,NULL),(111,0,1628486788,1,1,88,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Album\";i:1;s:20:\"tx_dlf_structures:88\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479223','',0,'',0,NULL,NULL),(112,0,1628486788,1,1,89,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"Address\";i:1;s:20:\"tx_dlf_structures:89\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479222','',0,'',0,NULL,NULL),(113,0,1628486788,1,1,90,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:10:\"Additional\";i:1;s:20:\"tx_dlf_structures:90\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479220','',0,'',0,NULL,NULL),(114,0,1628486788,1,1,91,'tx_dlf_structures',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:3:\"Act\";i:1;s:20:\"tx_dlf_structures:91\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc8479217','',0,'',0,NULL,NULL),(115,0,1628486790,1,1,1,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:23:\"tx_dlf_metadataformat:1\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5160','',0,'',0,NULL,NULL),(116,0,1628486790,1,1,2,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:23:\"tx_dlf_metadataformat:2\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b515e','',0,'',0,NULL,NULL),(117,0,1628486790,1,1,3,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:23:\"tx_dlf_metadataformat:3\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b515c','',0,'',0,NULL,NULL),(118,0,1628486790,1,1,4,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:23:\"tx_dlf_metadataformat:4\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b515a','',0,'',0,NULL,NULL),(119,0,1628486790,1,1,5,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:23:\"tx_dlf_metadataformat:5\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5158','',0,'',0,NULL,NULL),(120,0,1628486790,1,1,6,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:23:\"tx_dlf_metadataformat:6\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5155','',0,'',0,NULL,NULL),(121,0,1628486790,1,1,7,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:23:\"tx_dlf_metadataformat:7\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5153','',0,'',0,NULL,NULL),(122,0,1628486790,1,1,8,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:23:\"tx_dlf_metadataformat:8\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5152','',0,'',0,NULL,NULL),(123,0,1628486790,1,1,9,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:23:\"tx_dlf_metadataformat:9\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5151','',0,'',0,NULL,NULL),(124,0,1628486790,1,1,10,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:10\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b514f','',0,'',0,NULL,NULL),(125,0,1628486790,1,1,11,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:11\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b514e','',0,'',0,NULL,NULL),(126,0,1628486790,1,1,12,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:12\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b514d','',0,'',0,NULL,NULL),(127,0,1628486790,1,1,13,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:13\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b514b','',0,'',0,NULL,NULL),(128,0,1628486790,1,1,14,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:14\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b514a','',0,'',0,NULL,NULL),(129,0,1628486790,1,1,15,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:15\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5148','',0,'',0,NULL,NULL),(130,0,1628486790,1,1,16,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:16\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5147','',0,'',0,NULL,NULL),(131,0,1628486790,1,1,17,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:17\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5145','',0,'',0,NULL,NULL),(132,0,1628486790,1,1,18,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:18\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5144','',0,'',0,NULL,NULL),(133,0,1628486790,1,1,19,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:19\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5143','',0,'',0,NULL,NULL),(134,0,1628486790,1,1,20,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:20\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5141','',0,'',0,NULL,NULL),(135,0,1628486790,1,1,21,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:21\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5140','',0,'',0,NULL,NULL),(136,0,1628486790,1,1,22,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:22\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b513e','',0,'',0,NULL,NULL),(137,0,1628486790,1,1,23,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:23\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b513d','',0,'',0,NULL,NULL),(138,0,1628486790,1,1,24,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:24\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b513c','',0,'',0,NULL,NULL),(139,0,1628486790,1,1,25,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:25\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b513a','',0,'',0,NULL,NULL),(140,0,1628486790,1,1,26,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:26\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5139','',0,'',0,NULL,NULL),(141,0,1628486790,1,1,27,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:27\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5138','',0,'',0,NULL,NULL),(142,0,1628486790,1,1,28,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:28\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5136','',0,'',0,NULL,NULL),(143,0,1628486790,1,1,29,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:29\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5133','',0,'',0,NULL,NULL),(144,0,1628486790,1,1,30,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:30\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5132','',0,'',0,NULL,NULL),(145,0,1628486790,1,1,31,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:31\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b512f','',0,'',0,NULL,NULL),(146,0,1628486790,1,1,32,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:32\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b512e','',0,'',0,NULL,NULL),(147,0,1628486790,1,1,33,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:33\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b512c','',0,'',0,NULL,NULL),(148,0,1628486790,1,1,34,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:34\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b512b','',0,'',0,NULL,NULL),(149,0,1628486790,1,1,35,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:35\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5128','',0,'',0,NULL,NULL),(150,0,1628486790,1,1,36,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:36\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5124','',0,'',0,NULL,NULL),(151,0,1628486790,1,1,37,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"TEIHDR\";i:1;s:24:\"tx_dlf_metadataformat:37\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5123','',0,'',0,NULL,NULL),(152,0,1628486790,1,1,38,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"MODS\";i:1;s:24:\"tx_dlf_metadataformat:38\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5122','',0,'',0,NULL,NULL),(153,0,1628486790,1,1,39,'tx_dlf_metadataformat',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"IIIF2\";i:1;s:24:\"tx_dlf_metadataformat:39\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5115','',0,'',0,NULL,NULL),(154,0,1628486790,1,1,1,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:18:\"Rights Information\";i:1;s:17:\"tx_dlf_metadata:1\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5161','',0,'',0,NULL,NULL),(155,0,1628486790,1,1,2,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:18:\"Out Of Print Works\";i:1;s:17:\"tx_dlf_metadata:2\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b515f','',0,'',0,NULL,NULL),(156,0,1628486790,1,1,3,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:22:\"Restrictions on Access\";i:1;s:17:\"tx_dlf_metadata:3\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b515d','',0,'',0,NULL,NULL),(157,0,1628486790,1,1,4,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:12:\"Terms of Use\";i:1;s:17:\"tx_dlf_metadata:4\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b515b','',0,'',0,NULL,NULL),(158,0,1628486790,1,1,5,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"License\";i:1;s:17:\"tx_dlf_metadata:5\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5159','',0,'',0,NULL,NULL),(159,0,1628486790,1,1,6,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:11:\"Coordinates\";i:1;s:17:\"tx_dlf_metadata:6\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5156','',0,'',0,NULL,NULL),(160,0,1628486790,1,1,7,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:21:\"Kitodo Process Number\";i:1;s:17:\"tx_dlf_metadata:7\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5154','',0,'',0,NULL,NULL),(161,0,1628486790,1,1,8,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:14:\"OAI Identifier\";i:1;s:17:\"tx_dlf_metadata:8\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5150','',0,'',0,NULL,NULL),(162,0,1628486790,1,1,9,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:16:\"Union Catalog ID\";i:1;s:17:\"tx_dlf_metadata:9\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b514c','',0,'',0,NULL,NULL),(163,0,1628486790,1,1,10,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:15:\"OPAC Identifier\";i:1;s:18:\"tx_dlf_metadata:10\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5149','',0,'',0,NULL,NULL),(164,0,1628486790,1,1,11,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:3:\"URN\";i:1;s:18:\"tx_dlf_metadata:11\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5146','',0,'',0,NULL,NULL),(165,0,1628486790,1,1,12,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"PURL\";i:1;s:18:\"tx_dlf_metadata:12\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5142','',0,'',0,NULL,NULL),(166,0,1628486790,1,1,13,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Owner\";i:1;s:18:\"tx_dlf_metadata:13\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b513f','',0,'',0,NULL,NULL),(167,0,1628486790,1,1,14,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:13:\"Collection(s)\";i:1;s:18:\"tx_dlf_metadata:14\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b513b','',0,'',0,NULL,NULL),(168,0,1628486790,1,1,15,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"Language\";i:1;s:18:\"tx_dlf_metadata:15\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5137','',0,'',0,NULL,NULL),(169,0,1628486790,1,1,16,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:19:\"Year of Publication\";i:1;s:18:\"tx_dlf_metadata:16\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5134','',0,'',0,NULL,NULL),(170,0,1628486790,1,1,17,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:20:\"Place of Publication\";i:1;s:18:\"tx_dlf_metadata:17\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5130','',0,'',0,NULL,NULL),(171,0,1628486790,1,1,18,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Author\";i:1;s:18:\"tx_dlf_metadata:18\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b512d','',0,'',0,NULL,NULL),(172,0,1628486790,1,1,19,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:6:\"Volume\";i:1;s:18:\"tx_dlf_metadata:19\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5129','',0,'',0,NULL,NULL),(173,0,1628486790,1,1,20,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:5:\"Title\";i:1;s:18:\"tx_dlf_metadata:20\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b5125','',0,'',0,NULL,NULL),(174,0,1628486790,1,1,21,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:4:\"Type\";i:1;s:18:\"tx_dlf_metadata:21\";i:2;s:20:\"Kitodo Konfiguration\";i:3;i:2;}',2,0,'NEW6110bc86b511a','',0,'',0,NULL,NULL),(175,0,1628486790,1,2,1,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:18:\"Rights Information\";i:1;s:17:\"tx_dlf_metadata:1\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(176,0,1628486790,1,2,2,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:18:\"Out Of Print Works\";i:1;s:17:\"tx_dlf_metadata:2\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(177,0,1628486790,1,2,3,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:22:\"Restrictions on Access\";i:1;s:17:\"tx_dlf_metadata:3\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(178,0,1628486790,1,2,4,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:12:\"Terms of Use\";i:1;s:17:\"tx_dlf_metadata:4\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(179,0,1628486790,1,2,5,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:7:\"License\";i:1;s:17:\"tx_dlf_metadata:5\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(180,0,1628486790,1,2,6,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:11:\"Coordinates\";i:1;s:17:\"tx_dlf_metadata:6\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(181,0,1628486790,1,2,7,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:21:\"Kitodo Process Number\";i:1;s:17:\"tx_dlf_metadata:7\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(182,0,1628486790,1,2,8,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:14:\"OAI Identifier\";i:1;s:17:\"tx_dlf_metadata:8\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(183,0,1628486790,1,2,9,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:16:\"Union Catalog ID\";i:1;s:17:\"tx_dlf_metadata:9\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(184,0,1628486790,1,2,10,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:15:\"OPAC Identifier\";i:1;s:18:\"tx_dlf_metadata:10\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(185,0,1628486790,1,2,11,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:3:\"URN\";i:1;s:18:\"tx_dlf_metadata:11\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(186,0,1628486790,1,2,12,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:4:\"PURL\";i:1;s:18:\"tx_dlf_metadata:12\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(187,0,1628486790,1,2,13,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:5:\"Owner\";i:1;s:18:\"tx_dlf_metadata:13\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(188,0,1628486790,1,2,14,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:13:\"Collection(s)\";i:1;s:18:\"tx_dlf_metadata:14\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(189,0,1628486790,1,2,15,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:8:\"Language\";i:1;s:18:\"tx_dlf_metadata:15\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(190,0,1628486790,1,2,16,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:19:\"Year of Publication\";i:1;s:18:\"tx_dlf_metadata:16\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(191,0,1628486790,1,2,17,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:20:\"Place of Publication\";i:1;s:18:\"tx_dlf_metadata:17\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(192,0,1628486790,1,2,18,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Author\";i:1;s:18:\"tx_dlf_metadata:18\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(193,0,1628486790,1,2,19,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Volume\";i:1;s:18:\"tx_dlf_metadata:19\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(194,0,1628486790,1,2,20,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:5:\"Title\";i:1;s:18:\"tx_dlf_metadata:20\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(195,0,1628486790,1,2,21,'tx_dlf_metadata',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:4:\"Type\";i:1;s:18:\"tx_dlf_metadata:21\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(196,0,1628487239,1,1,1,'sys_language',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:7:\"English\";i:1;s:14:\"sys_language:1\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW6110be3811bc4449292275','',0,'',0,NULL,NULL),(197,0,1628488695,1,1,1,'sys_template',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'141.66.6.77','a:4:{i:0;s:8:\"NEW SITE\";i:1;s:14:\"sys_template:1\";i:2;s:6:\"Viewer\";i:3;i:1;}',1,0,'NEW','',0,'',0,NULL,NULL),(198,0,1628488695,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'141.66.6.77','a:2:{i:0;s:6:\"kitodo\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(199,0,1628488724,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"166\";}',1,0,'','',0,'',0,NULL,NULL),(200,0,1628488854,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"167\";}',1,0,'','',0,'',0,NULL,NULL),(201,0,1628488976,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";i:0;}',1,0,'','',0,'',0,NULL,NULL),(202,0,1628489093,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"168\";}',1,0,'','',0,'',0,NULL,NULL),(203,0,1628490668,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";i:0;}',1,0,'','',0,'',0,NULL,NULL),(204,0,1628508786,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"169\";}',1,0,'','',0,'',0,NULL,NULL),(205,0,1628509476,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";i:0;}',1,0,'','',0,'',0,NULL,NULL),(206,0,1628514076,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /data/www/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: http://ddb-p2-vmzpviewer01:8001/zp-viewertypo3conf/ext/ddb_kitodo_zeitungsportal/Resources/Public/JavaScript/ddbKitodoZeitungsportal.js?1628166000',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(207,0,1628516286,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(208,0,1628581758,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /data/www/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: http://ddb-p2-vmzpviewer01:8001/zp-viewertypo3conf/ext/ddb_kitodo_zeitungsportal/Resources/Public/JavaScript/ddbKitodoZeitungsportal.js?1628166000',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(209,0,1628581760,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /data/www/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: http://ddb-p2-vmzpviewer01:8001/zp-viewertypo3conf/ext/ddb_kitodo_zeitungsportal/Resources/Public/JavaScript/ddbKitodoZeitungsportal.js?1628166000',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(210,0,1628581976,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(211,0,1628768368,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(212,0,1628768475,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"170\";}',1,0,'','',0,'',0,NULL,NULL),(213,0,1628768475,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1390337130: No cache in the specified group \'pages\' | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheGroupException thrown in file /data/www/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 226. Requested URL: http://ddb-p2-vmzpviewer01:8001/typo3/index.php?route=%%2Frecord%%2Fedit&token=--AnonymizedToken--&edit%%5Bsys_template%%5D%%5B1%%5D=edit&createExtension=0&returnUrl=%%2Ftypo3%%2Findex.php%%3Froute%%3D%%252Fweb%%252Fts%%252F%%26token%%3D8474852acd9f041c054176b33e80a2e6cbb4f980%%26id%%3D1',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(214,0,1628833663,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(215,0,1628833686,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"171\";}',1,0,'','',0,'',0,NULL,NULL),(216,0,1628833686,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1390337130: No cache in the specified group \'pages\' | TYPO3\\CMS\\Core\\Cache\\Exception\\NoSuchCacheGroupException thrown in file /data/www/public/typo3/sysext/core/Classes/Cache/CacheManager.php in line 226. Requested URL: http://ddb-p2-vmzpviewer01:8001/typo3/index.php?route=%%2Frecord%%2Fedit&token=--AnonymizedToken--&edit%%5Bsys_template%%5D%%5B1%%5D=edit&createExtension=0&returnUrl=%%2Ftypo3%%2Findex.php%%3Froute%%3D%%252Fweb%%252Fts%%252F%%26token%%3Dce63fa07f8efed4f119a5b9a11aff89c94ec8ff1%%26id%%3D1',5,0,'141.66.6.77','',-1,0,'','',0,'',0,NULL,NULL),(217,0,1628837141,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"172\";}',1,0,'','',0,'',0,NULL,NULL),(218,0,1628837146,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"173\";}',1,0,'','',0,'',0,NULL,NULL),(219,0,1629101048,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(220,0,1629117739,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(221,0,1629117750,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(222,0,1629117771,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(223,0,1629117771,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(224,0,1629117788,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(225,0,1629117839,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(226,0,1629117853,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(227,0,1629117942,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(228,0,1629117974,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(229,0,1629118044,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(230,0,1629118145,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(231,0,1629118197,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(232,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(233,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(234,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(235,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(236,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(237,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(238,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(239,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(240,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(241,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(242,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(243,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(244,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(245,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(246,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(247,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(248,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(249,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(250,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(251,0,1629118366,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(252,0,1629118366,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(253,0,1629118366,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(254,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(255,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(256,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(257,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(258,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(259,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(260,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(261,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(262,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(263,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(264,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(265,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(266,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(267,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(268,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(269,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(270,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(271,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(272,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(273,0,1629118395,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(274,0,1629118395,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(275,0,1629118395,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(276,0,1629118724,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"174\";}',1,0,'','',0,'',0,NULL,NULL),(277,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(278,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(279,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(280,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(281,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(282,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(283,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(284,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(285,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(286,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(287,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(288,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(289,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(290,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(291,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(292,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(293,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(294,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(295,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_keys() expects parameter 1 to be array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(296,0,1629119405,0,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: array_intersect(): Expected parameter 2 to be an array, null given in /data/www/public/typo3conf/ext/dlf/Classes/Plugin/PageGrid.php line 58',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(297,0,1629119406,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(298,0,1629119406,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(299,0,1629119436,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(300,0,1629119436,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(301,0,1629119531,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"175\";}',1,0,'','',0,'',0,NULL,NULL),(302,0,1629119706,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";i:0;}',1,0,'','',0,'',0,NULL,NULL),(303,0,1629119750,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(304,0,1629119750,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1580585079: No valid parameter passed! | InvalidArgumentException thrown in file /data/www/public/typo3conf/ext/dlf/Classes/Plugin/Eid/SearchInDocument.php in line 49. Requested URL: http://viewer-dzp.deutsche-digitale-bibliothek.de/',5,0,'141.66.131.251','',-1,0,'','',0,'',0,NULL,NULL),(305,0,1629120019,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"176\";}',1,0,'','',0,'',0,NULL,NULL),(306,0,1629120437,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"177\";}',1,0,'','',0,'',0,NULL,NULL),(307,0,1629180200,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'141.66.6.77','a:1:{i:0;s:6:\"kitodo\";}',-1,-99,'','',0,'',0,NULL,NULL),(308,0,1629180334,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"178\";}',1,0,'','',0,'',0,NULL,NULL),(309,0,1629180334,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'141.66.6.77','a:2:{i:0;s:6:\"kitodo\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(310,0,1629180466,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'141.66.6.77','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"179\";}',1,0,'','',0,'',0,NULL,NULL),(311,0,1629180466,1,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'141.66.6.77','a:2:{i:0;s:6:\"kitodo\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(312,0,1629184438,3,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(313,0,1629184457,3,1,0,'',0,0,'Personal settings changed',254,1,'172.18.0.7','a:0:{}',-1,0,'','',0,'',0,NULL,NULL),(314,0,1629184457,3,2,3,'be_users',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:5:\"admin\";i:1;s:10:\"be_users:3\";s:7:\"history\";s:3:\"180\";}',0,0,'','',0,'',0,NULL,NULL),(315,0,1629184464,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1534710048: No pseudo-site found in root line of page 2 | TYPO3\\CMS\\Core\\Exception\\SiteNotFoundException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Site/PseudoSiteFinder.php in line 189. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/typo3/index.php?route=%%2Fweb%%2Flayout%%2F&token=--AnonymizedToken--&id=2',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(316,0,1629184709,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1534710048: No pseudo-site found in root line of page 2 | TYPO3\\CMS\\Core\\Exception\\SiteNotFoundException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Site/PseudoSiteFinder.php in line 189. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/typo3/index.php?route=%%2Frecord%%2Fedit&token=--AnonymizedToken--&edit[tx_dlf_solrcores][1]=edit&returnUrl=%%2Ftypo3%%2Findex.php%%3Froute%%3D%%252Fweb%%252Flist%%252F%%26token%%3D4ac44c8c000436591c88046636da642bb5bb899d%%26id%%3D2%%26table%%3D%%26imagemode%%3D1',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(317,0,1629184738,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1534710048: No pseudo-site found in root line of page 2 | TYPO3\\CMS\\Core\\Exception\\SiteNotFoundException thrown in file /var/www/html/public/typo3/sysext/core/Classes/Site/PseudoSiteFinder.php in line 189. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/typo3/index.php?route=%%2Frecord%%2Fedit&token=--AnonymizedToken--&edit[pages][2]=edit&returnUrl=%%2Ftypo3%%2Findex.php%%3Froute%%3D%%252Fweb%%252Flist%%252F%%26token%%3D4ac44c8c000436591c88046636da642bb5bb899d%%26id%%3D2%%26table%%3D%%26imagemode%%3D1',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(318,0,1629184744,3,4,2,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,2,'172.18.0.7','a:4:{i:0;s:20:\"Kitodo Konfiguration\";i:1;s:7:\"pages:2\";i:2;s:6:\"Viewer\";i:3;i:1;}',0,0,'','',0,'',0,NULL,NULL),(319,0,1629184744,3,4,2,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,3,'172.18.0.7','a:4:{i:0;s:20:\"Kitodo Konfiguration\";i:1;s:7:\"pages:2\";i:2;s:12:\"[root-level]\";i:3;i:0;}',1,0,'','',0,'',0,NULL,NULL),(320,0,1629184744,3,2,2,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:20:\"Kitodo Konfiguration\";i:1;s:7:\"pages:2\";s:7:\"history\";i:0;}',2,0,'','',0,'',0,NULL,NULL),(321,0,1629184764,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(322,0,1629184863,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"182\";}',1,0,'','',0,'',0,NULL,NULL),(323,0,1629185218,3,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:7:\"pages:1\";s:7:\"history\";s:3:\"183\";}',1,0,'','',0,'',0,NULL,NULL),(324,0,1629188462,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"184\";}',1,0,'','',0,'',0,NULL,NULL),(325,0,1629188464,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(326,0,1629189447,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"185\";}',1,0,'','',0,'',0,NULL,NULL),(327,0,1629191629,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(328,0,1629191718,3,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: file_get_contents(typo3conf/ext/ddb_kitodo_zeitungsportal/Resources/Private/Plugins/Kitodo/SearchInDocumentTool.html): failed to open stream: No such file or directory in /var/www/html/public/typo3conf/ext/dlf/Classes/Common/AbstractPlugin.php line 88',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(329,0,1629191734,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(330,0,1629191735,3,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: file_get_contents(typo3conf/ext/ddb_kitodo_zeitungsportal/Resources/Private/Plugins/Kitodo/SearchInDocumentTool.html): failed to open stream: No such file or directory in /var/www/html/public/typo3conf/ext/dlf/Classes/Common/AbstractPlugin.php line 88',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(331,0,1629191753,3,0,0,'',0,1,'Core: Error handler (FE): PHP Warning: file_get_contents(typo3conf/ext/ddb_kitodo_zeitungsportal/Resources/Private/Plugins/Kitodo/SearchInDocumentTool.html): failed to open stream: No such file or directory in /var/www/html/public/typo3conf/ext/dlf/Classes/Common/AbstractPlugin.php line 88',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(332,0,1630422448,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(333,0,1630422460,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(334,0,1630422470,3,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(335,0,1630422828,3,1,3,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.18.0.6','a:4:{i:0;s:30:\"[Translate to English:] Viewer\";i:1;s:7:\"pages:3\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW612e472cceb02301900992','',0,'',0,NULL,NULL),(336,0,1630422831,3,2,3,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.6','a:3:{i:0;s:30:\"[Translate to English:] Viewer\";i:1;s:7:\"pages:3\";s:7:\"history\";s:3:\"187\";}',3,0,'','',0,'',0,NULL,NULL),(337,0,1630422840,3,2,3,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.6','a:3:{i:0;s:30:\"[Translate to English:] Viewer\";i:1;s:7:\"pages:3\";s:7:\"history\";i:0;}',3,0,'','',0,'',0,NULL,NULL),(338,0,1630422842,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(339,0,1630422906,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/en/https://ddev-ddb-zeitungsportal.ddev.site/en/',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(340,0,1630424583,3,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,0,'','',0,'',0,NULL,NULL),(341,0,1630425883,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(342,0,1630442375,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(343,0,1630442541,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/en?html=1&tx_dlf%%5Bid%%5D=https://dev-ddb.fiz-karlsruhe.de/api/items/AS5ZQUFT7XHPUYIKTJXX7XD2NHFV34MM/source/record&tx_dlf%%5Bpage%%5D=1&_=1630425850740',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(344,0,1630442543,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/en?html=1&tx_dlf%%5Bid%%5D=https://dev-ddb.fiz-karlsruhe.de/api/items/AS5ZQUFT7XHPUYIKTJXX7XD2NHFV34MM/source/record&tx_dlf%%5Bpage%%5D=1&_=1630425850740',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(345,0,1630442544,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/en?html=1&tx_dlf%%5Bid%%5D=https://dev-ddb.fiz-karlsruhe.de/api/items/AS5ZQUFT7XHPUYIKTJXX7XD2NHFV34MM/source/record&tx_dlf%%5Bpage%%5D=1&_=1630425850740',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(346,0,1630444244,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/en?html=1&tx_dlf%%5Bid%%5D=https://dev-ddb.fiz-karlsruhe.de/api/items/AS5ZQUFT7XHPUYIKTJXX7XD2NHFV34MM/source/record&tx_dlf%%5Bpage%%5D=1&_=1630425850740',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(347,0,1630446987,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(348,0,1630447473,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(349,0,1630491197,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(350,0,1630491201,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(351,0,1630491207,3,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(352,0,1630491219,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(353,0,1630492911,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.6','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"188\";}',1,0,'','',0,'',0,NULL,NULL),(354,0,1630492918,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.6','',-1,0,'','',0,'',0,NULL,NULL),(355,0,1630493064,3,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,0,'','',0,'',0,NULL,NULL),(356,0,1630493068,3,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,0,'','',0,'',0,NULL,NULL),(357,0,1630493856,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(358,0,1630493865,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(359,0,1630499822,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.6','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(360,0,1630500948,3,1,4,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.18.0.6','a:4:{i:0;s:9:\"Viewerdev\";i:1;s:7:\"pages:4\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW612f784e3e4b5207938644','',0,'',0,NULL,NULL),(361,0,1630500951,3,4,4,'pages',0,0,'Moved record \'%s\' (%s) to page \'%s\' (%s)',1,2,'172.18.0.6','a:4:{i:0;s:9:\"Viewerdev\";i:1;s:7:\"pages:4\";i:2;s:6:\"Viewer\";i:3;i:1;}',0,0,'','',0,'',0,NULL,NULL),(362,0,1630500951,3,4,4,'pages',0,0,'Moved record \'%s\' (%s) from page \'%s\' (%s)',1,3,'172.18.0.6','a:4:{i:0;s:9:\"Viewerdev\";i:1;s:7:\"pages:4\";i:2;s:12:\"[root-level]\";i:3;i:0;}',1,0,'','',0,'',0,NULL,NULL),(363,0,1630500951,3,2,4,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.6','a:3:{i:0;s:9:\"Viewerdev\";i:1;s:7:\"pages:4\";s:7:\"history\";i:0;}',4,0,'','',0,'',0,NULL,NULL),(364,0,1630500958,3,2,4,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.6','a:3:{i:0;s:9:\"Viewerdev\";i:1;s:7:\"pages:4\";s:7:\"history\";s:3:\"191\";}',4,0,'','',0,'',0,NULL,NULL),(365,0,1630500985,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.6','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"192\";}',1,0,'','',0,'',0,NULL,NULL),(366,0,1631137194,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(367,0,1631137274,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(368,0,1631137284,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(369,0,1631137299,3,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(370,0,1631137606,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"193\";}',1,0,'','',0,'',0,NULL,NULL),(371,0,1631137639,3,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,0,'','',0,'',0,NULL,NULL),(372,0,1631137842,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"194\";}',1,0,'','',0,'',0,NULL,NULL),(373,0,1631137866,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"195\";}',1,0,'','',0,'',0,NULL,NULL),(374,0,1631137868,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(375,0,1631137870,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1294587217: The page is not configured! [type=0][]. This means that there is no TypoScript object of type PAGE with typeNum=0 configured. | TYPO3\\CMS\\Core\\Error\\Http\\ServiceUnavailableException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/TypoScriptFrontendController.php in line 2633. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/?issue_id=IQA4GMYQPAQGBYURU26RZNXA4Y55HSGN&tx_dlf[highlight_word]=Reise&issuepage=4&debug=1&tx_dlf%%5Bid%%5D=https://api-q1.deutsche-digitale-bibliothek.de/items/IQA4GMYQPAQGBYURU26RZNXA4Y55HSGN/source/record&tx_dlf[page]=4',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(376,0,1631137883,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"196\";}',1,0,'','',0,'',0,NULL,NULL),(377,0,1631138594,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(378,0,1631138665,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(379,0,1631138760,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(380,0,1631138780,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(381,0,1631138890,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(382,0,1631138926,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(383,0,1631138928,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(384,0,1631138991,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(385,0,1631139390,3,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(386,0,1632298940,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1518472189: The requested page does not exist | TYPO3\\CMS\\Core\\Error\\Http\\PageNotFoundException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/ErrorController.php in line 80. Requested URL: https://ddev-ddb-zeitungsportal.ddev.site/favicon.ico',5,0,'172.18.0.7','',-1,0,'','',0,'',0,NULL,NULL),(387,0,1632298967,3,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(388,0,1632299231,3,2,4,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:9:\"Viewerdev\";i:1;s:7:\"pages:4\";s:7:\"history\";s:3:\"197\";}',4,0,'','',0,'',0,NULL,NULL),(389,0,1632299318,3,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,1,'172.18.0.7','a:1:{i:0;s:5:\"admin\";}',-1,0,'','',0,'',0,NULL,NULL),(390,0,1632299811,3,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.18.0.7','a:3:{i:0;s:6:\"Viewer\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:3:\"198\";}',1,0,'','',0,'',0,NULL,NULL),(391,0,1632299830,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL),(392,0,1632299888,3,1,0,'',0,0,'User %s has cleared the cache (cacheCmd=%s)',3,0,'172.18.0.7','a:2:{i:0;s:5:\"admin\";i:1;s:3:\"all\";}',-1,0,'','',0,'',0,NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdby` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `source_host` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `source_path` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `target_statuscode` int(11) NOT NULL DEFAULT 307,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `lasthiton` int(11) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('000447944b7e965b415fe0fc68453d4d','tx_dlf_metadata',20,'format','','','',0,0,0,'tx_dlf_metadataformat',38,''),('0075f2acfa174e64ef3d662505777d68','tx_dlf_metadataformat',12,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('023cb3e32d87847e6276b605da5f63f2','tx_dlf_metadata',12,'format','','','',0,0,0,'tx_dlf_metadataformat',21,''),('03978c5061c2b15ff94a40012460525a','tx_dlf_metadataformat',29,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('04e397f57dbe63c88e07e1832ef6a97c','tx_dlf_metadata',18,'format','','','',0,0,0,'tx_dlf_metadataformat',34,''),('0a0266f64d2836b2dbbee3fbc89b9e34','tx_dlf_metadata',8,'format','','','',2,0,0,'tx_dlf_metadataformat',10,''),('112151e599b1bcf745cd5e9bbf363ba7','tx_dlf_metadata',14,'format','','','',1,0,0,'tx_dlf_metadataformat',26,''),('187bedf02a8c41e22365151bc02bf669','tx_dlf_metadataformat',15,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('18ee27530711a2f9108a199e831cff4d','tx_dlf_metadataformat',2,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('1e994b9c6c587325fe3740f417874dc7','tx_dlf_metadata',11,'format','','','',1,0,0,'tx_dlf_metadataformat',18,''),('22b888b5ca89beaec430d8f089eba411','tx_dlf_metadataformat',36,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('22ff74720e03cec5505692758bf3881e','tx_dlf_metadata',14,'format','','','',0,0,0,'tx_dlf_metadataformat',27,''),('26767e398bf10e85f37133e8fbac55e2','sys_template',1,'config','','url','17',-1,0,0,'_STRING',0,'https://api-q1.deutsche-digitale-bibliothek.de/items/*id*/source/record'),('28a970a910b9961bb97ef8f9501a2681','sys_template',1,'constants','','url','7',-1,0,0,'_STRING',0,'https://ddev-ddb-zeitungsportal.ddev.site/'),('29c716f09329531cfceeb35aae6a2548','sys_template',1,'config','','url','7',-1,0,0,'_STRING',0,'https://dev-ddb.fiz-karlsruhe.de/ddb-current/newspaper/item'),('2f9355eac04f6fca3de7812061925cf4','tx_dlf_metadata',1,'format','','','',0,0,0,'tx_dlf_metadataformat',1,''),('33ad9e7269da302d8eedb40a5193bbaf','tx_dlf_metadataformat',31,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('35f3f9b4a9fc5d08bf32db9bca14672c','tx_dlf_metadataformat',25,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('429bc85e1c7d0c6f16a3123ea3970aff','tx_dlf_metadata',7,'format','','','',1,0,0,'tx_dlf_metadataformat',8,''),('444fb7f788d97f1e7a1d306c8888e1a6','tx_dlf_metadataformat',38,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('45da6d7c34ad57ef6d2903a3082e7418','tx_dlf_metadataformat',9,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('46856096d5e99afb758d25d30932b20c','tx_dlf_metadataformat',27,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('46a5589e1e3c705bfc92567bab063840','tx_dlf_metadataformat',18,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('473b1f1987099892908653a9b21a691c','tx_dlf_metadata',9,'format','','','',0,0,0,'tx_dlf_metadataformat',14,''),('47dcf0a2ed2167e9c90e025944f665e7','tx_dlf_metadataformat',22,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('48cc77b19b8e53a58862d02e4b0f62c2','tx_dlf_metadataformat',6,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('518d0e7609add3167563b0d2d3acf482','tx_dlf_metadataformat',37,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('5c3adbd97d056645324fce8ea8a23f69','tx_dlf_metadata',17,'format','','','',0,0,0,'tx_dlf_metadataformat',32,''),('5d0daac8125d2138b330185bbc868452','tx_dlf_metadata',7,'format','','','',0,0,0,'tx_dlf_metadataformat',9,''),('5e5ccb335e7854912c87b7f19fdeca38','tx_dlf_metadataformat',14,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('60d9df1512ebc084aea485721892ccb8','tx_dlf_metadata',12,'format','','','',1,0,0,'tx_dlf_metadataformat',20,''),('650c79e38b11b9ec476fef5095c56a83','tx_dlf_metadataformat',20,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('65b236710fe3a3029d8dc5b62214f437','tx_dlf_metadata',2,'format','','','',0,0,0,'tx_dlf_metadataformat',2,''),('6b32820f8b697ffc8a6fdc149d8f4dc3','tx_dlf_metadata',9,'format','','','',1,0,0,'tx_dlf_metadataformat',13,''),('6cdf67dbaa437acf12df7cecde146f01','tx_dlf_metadata',5,'format','','','',0,0,0,'tx_dlf_metadataformat',5,''),('6e6919d545d458197b6b2e205e474fdd','tx_dlf_metadataformat',24,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('710d6dc8cc5473a73cc284f2052b3195','tx_dlf_metadata',20,'format','','','',1,0,0,'tx_dlf_metadataformat',37,''),('715e9343823fab6743ac0143d2112fd8','tx_dlf_metadata',16,'format','','','',0,0,0,'tx_dlf_metadataformat',30,''),('726b1e19c47b6749826f493557752fdb','tx_dlf_metadataformat',5,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('74af6b1584f2567f4b28f60ce2ff694d','tx_dlf_metadataformat',21,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('765aa56f29a86cd4930912eeacba195c','tx_dlf_metadata',19,'format','','','',0,0,0,'tx_dlf_metadataformat',35,''),('7a61e3b3791e0841e589d880c21b77ba','tx_dlf_metadataformat',17,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('7e9687406c84dba2286f5566b757c4ef','tx_dlf_metadataformat',10,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('7f0038c0815d80fbcc2a447c878203b6','tx_dlf_metadata',4,'format','','','',0,0,0,'tx_dlf_metadataformat',4,''),('85bbf1a82475adaff53ab413752a1bb0','tx_dlf_metadata',16,'format','','','',1,0,0,'tx_dlf_metadataformat',29,''),('86594571594f89224b063defb602109c','tx_dlf_metadataformat',13,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('86cd3602321044ae16e0490005879571','tx_dlf_metadataformat',16,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('8b88ceea81b937c5752462a7802331b7','tx_dlf_metadata',13,'format','','','',0,0,0,'tx_dlf_metadataformat',24,''),('8d8ac51de84835e2f4ee4dcfb1459440','tx_dlf_metadata',17,'format','','','',1,0,0,'tx_dlf_metadataformat',31,''),('8e6eb050e8e76d7486fc7a2d74bc0337','tx_dlf_metadata',8,'format','','','',1,0,0,'tx_dlf_metadataformat',11,''),('971a0b204fdddc514fd4b81d01a00e5f','tx_dlf_metadata',10,'format','','','',0,0,0,'tx_dlf_metadataformat',16,''),('99717449204dc3dc44edb6897c039f48','tx_dlf_metadata',7,'format','','','',2,0,0,'tx_dlf_metadataformat',7,''),('a2d220218c3b536a24de0d00042a4781','tx_dlf_metadata',18,'format','','','',1,0,0,'tx_dlf_metadataformat',33,''),('a3247013b70b5d7d0aeb3a42c96ec1a2','sys_template',1,'config','','url','2',-1,0,0,'_STRING',0,'https://dev-ddb.fiz-karlsruhe.de/api/items/*id*/source/record'),('a58f2b7376bb99cf7b34081d15fde403','tx_dlf_metadataformat',35,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('abbd3ebd07934e1b0a8aad15326a2905','tx_dlf_metadataformat',30,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('ad9154ee33bc2fd4ef30310a14dd6638','tx_dlf_metadata',11,'format','','','',2,0,0,'tx_dlf_metadataformat',17,''),('ae5f8ba6be21fa5141abffa1f8a7b8f8','tx_dlf_metadataformat',32,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('b185be0113444f3a55d454ad5bc9a84a','tx_dlf_metadata',6,'format','','','',0,0,0,'tx_dlf_metadataformat',6,''),('b633a37756891be4bb2eb012ca2503ea','tx_dlf_metadata',8,'format','','','',0,0,0,'tx_dlf_metadataformat',12,''),('b73b6be951ae6024ed7e6637a8d90f4c','sys_template',1,'constants','','url','12',-1,0,0,'_STRING',0,'http://ddb-p2-vmzpviewer01:8001/zp-viewer'),('bfccd642a7dd7c6620dd0809f8380f92','tx_dlf_metadata',13,'format','','','',2,0,0,'tx_dlf_metadataformat',22,''),('c1304c959d93a6a7bf1805fb07456f1a','tx_dlf_metadata',21,'format','','','',0,0,0,'tx_dlf_metadataformat',39,''),('c1403026134c112ddca9b3a408d5c551','tx_dlf_metadata',15,'format','','','',0,0,0,'tx_dlf_metadataformat',28,''),('c56846b88eeafa51b5e84f6f24981a6d','tx_dlf_metadata',20,'format','','','',2,0,0,'tx_dlf_metadataformat',36,''),('c6b769669fb61b9c856e090e2712be3d','tx_dlf_metadataformat',4,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('c8e9ad29e9dd0dc9b1308cb507e1ee3d','tx_dlf_metadata',14,'format','','','',2,0,0,'tx_dlf_metadataformat',25,''),('cf884179835c74249c38d23801e85968','pages',3,'l10n_parent','','','',0,0,0,'pages',1,''),('d0b5b2222ab19f69f3f9934839851b2a','tx_dlf_metadataformat',11,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('d276d8f98c2bf7d8c5ec5bc240380331','tx_dlf_metadata',11,'format','','','',0,0,0,'tx_dlf_metadataformat',19,''),('db8decf6bd423d822fcc703e51824946','sys_template',1,'constants','','url','2',-1,0,0,'_STRING',0,'https://viewer-dzp.deutsche-digitale-bibliothek.de/'),('e128dfa6b3f4d6bfb11241ee32862c79','tx_dlf_metadataformat',7,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('e26476d4086e95b61a8adf3b85850782','tx_dlf_metadataformat',28,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('ef9bae24c9fa95d3a61cb2cb2f177586','sys_template',1,'config','','url','12',-1,0,0,'_STRING',0,'https://dev-ddb.fiz-karlsruhe.de/ddb-current/newspaper/item'),('f0c3f3db8bdeba6947457a9c3e2a17f0','tx_dlf_metadataformat',34,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('f1996d58b4e1dfa58e3fdeb2a1d50a77','tx_dlf_metadataformat',3,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('f1be1edc330ef2d5d439f50f8ae37523','tx_dlf_metadata',13,'format','','','',1,0,0,'tx_dlf_metadataformat',23,''),('f44ba30d031ab74449be752c40ff0027','pages',3,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('f66941f4d688bbc259f59634265fe66f','tx_dlf_metadata',3,'format','','','',0,0,0,'tx_dlf_metadataformat',3,''),('f6814ee8d36e8ec0418b3a07754d1e17','tx_dlf_metadataformat',33,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('f71e8a57f495428a75fcb9c4465bf3c6','tx_dlf_metadataformat',23,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('f8325bb2b0d434e9fcfca607b81c1d86','tx_dlf_metadataformat',1,'encoded','','','',0,0,0,'tx_dlf_formats',1,''),('fc1acc0086bee070ce20b7cb65946b5c','tx_dlf_metadata',10,'format','','','',1,0,0,'tx_dlf_metadataformat',15,''),('fc1dab03d6ea42807d41a3636a821b77','tx_dlf_metadataformat',8,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('fc9338dfcac76e6898747f1bcb81d871','tx_dlf_metadataformat',26,'encoded','','','',0,0,0,'tx_dlf_formats',2,''),('fc9e3b5a0b45a9c80761c81c82bdbcca','tx_dlf_metadataformat',39,'encoded','','','',0,0,0,'tx_dlf_formats',5,''),('fe22b05a214bf4abd42b0934b7fa766a','tx_dlf_metadataformat',19,'encoded','','','',0,0,0,'tx_dlf_formats',1,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserConfigurationUpdate','i:1;'),(30,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(31,'installUpdateRows','rowUpdatersDone','a:3:{i:0;s:52:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L10nModeUpdater\";i:1;s:53:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\ImageCropUpdater\";i:2;s:57:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\RteLinkSyntaxUpdater\";}'),(32,'core','formProtectionSessionToken:1','s:64:\"bf34562f5acd067887376f58c6aa381dfde3c1d4a0e8c4e3f3007447bfc5e3b4\";'),(33,'languagePacks','baseUrl','s:44:\"https://extensions.typo3.org/fileadmin/l10n/\";'),(34,'extensionDataImport','typo3conf/ext/dlf/ext_tables_static+adt.sql','s:0:\"\";'),(35,'core','formProtectionSessionToken:3','s:64:\"436d19fad04507b751cb76d1593c8fa784a3021aa721e86f7a01ecfa9b0e2f50\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sitetitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nextLevel` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `basedOn` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1632299811,1628488695,1,0,0,0,0,256,NULL,0,0,0,'',0,0,0,0,0,0,'Viewer','',1,3,'EXT:dlf/Configuration/TypoScript/TableOfContents/,EXT:dlf/Configuration/TypoScript/Toolbox/,EXT:ddb_kitodo_zeitungsportal/Configuration/TypoScript','constant {\r\n  # id of configuration directory (Kitodo Konfiguration)\r\n  configPid = 2\r\n  # id of Viewer page\r\n  viewerPid = 4\r\n  #page url on which viewer will be visible\r\n  #baseUrl = https://viewer-dzp.deutsche-digitale-bibliothek.de/\r\n  baseUrl = https://ddev-ddb-zeitungsportal.ddev.site/\r\n  #baseUrl = http://ddb-p2-vmzpviewer01:8001/zp-viewer\r\n}','# dev\r\nplugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https://dev-ddb.fiz-karlsruhe.de/api/items/*id*/source/record\r\nplugin.tx_dlf_searchindocumenttool.searchUrl = https://dev-ddb.fiz-karlsruhe.de/ddb-current/newspaper/item\r\n\r\n# master\r\n#plugin.tx_dlf_searchindocumenttool.searchUrl = https://dev-ddb.fiz-karlsruhe.de/ddb-current/newspaper/item\r\n#plugin.tx_dlf_searchindocumenttool.documentIdUrlSchema = https://api-q1.deutsche-digitale-bibliothek.de/items/*id*/source/record\r\n\r\n','','',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `spaceBefore` smallint(5) unsigned NOT NULL DEFAULT 0,
  `spaceAfter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(17) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `selected_categories` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_field` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_actionlog`
--

DROP TABLE IF EXISTS `tx_dlf_actionlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_actionlog` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `count_pages` int(11) NOT NULL DEFAULT 0,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_actionlog`
--

LOCK TABLES `tx_dlf_actionlog` WRITE;
/*!40000 ALTER TABLE `tx_dlf_actionlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_actionlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_basket`
--

DROP TABLE IF EXISTS `tx_dlf_basket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_basket` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(11) NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob NOT NULL,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fe_user_id` int(11) NOT NULL DEFAULT 0,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `session_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `doc_ids` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_basket`
--

LOCK TABLES `tx_dlf_basket` WRITE;
/*!40000 ALTER TABLE `tx_dlf_basket` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_basket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_collections`
--

DROP TABLE IF EXISTS `tx_dlf_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_collections` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(11) NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob NOT NULL,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `fe_group` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fe_cruser_id` int(11) NOT NULL DEFAULT 0,
  `fe_admin_lock` smallint(6) NOT NULL DEFAULT 0,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `index_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `index_search` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `oai_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` smallint(6) NOT NULL DEFAULT 3,
  `documents` int(11) NOT NULL DEFAULT 0,
  `owner` int(11) NOT NULL DEFAULT 0,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `index_name` (`index_name`),
  KEY `oai_name` (`oai_name`),
  KEY `pid_cruser` (`pid`,`fe_cruser_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_collections`
--

LOCK TABLES `tx_dlf_collections` WRITE;
/*!40000 ALTER TABLE `tx_dlf_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_documents`
--

DROP TABLE IF EXISTS `tx_dlf_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_documents` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `starttime` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `fe_group` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `prod_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `record_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opac_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `union_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `urn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purl` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_sorting` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `place` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `metadata` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata_sorting` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `structure` int(11) NOT NULL DEFAULT 0,
  `partof` int(11) NOT NULL DEFAULT 0,
  `volume` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `volume_sorting` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `license` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `terms` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `restrictions` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `out_of_print` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rights_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `collections` int(11) NOT NULL DEFAULT 0,
  `mets_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mets_orderlabel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `owner` int(11) NOT NULL DEFAULT 0,
  `solrcore` int(11) NOT NULL DEFAULT 0,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `document_format` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `location` (`location`),
  KEY `record_id` (`record_id`),
  KEY `partof` (`partof`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_documents`
--

LOCK TABLES `tx_dlf_documents` WRITE;
/*!40000 ALTER TABLE `tx_dlf_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_formats`
--

DROP TABLE IF EXISTS `tx_dlf_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_formats` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `root` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `namespace` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_formats`
--

LOCK TABLES `tx_dlf_formats` WRITE;
/*!40000 ALTER TABLE `tx_dlf_formats` DISABLE KEYS */;
INSERT INTO `tx_dlf_formats` VALUES (1,0,1628166052,1628166052,1,0,'MODS','mods','http://www.loc.gov/mods/v3','Kitodo\\Dlf\\Format\\Mods'),(2,0,1628166052,1628166052,1,0,'TEIHDR','teiHeader','http://www.tei-c.org/ns/1.0','Kitodo\\Dlf\\Format\\TeiHeader'),(3,0,1628166052,1628166052,1,0,'ALTO','alto','http://www.loc.gov/standards/alto/ns-v2#','Kitodo\\Dlf\\Format\\Alto'),(4,0,1628166052,1628166052,1,0,'IIIF1','IIIF1','http://www.shared-canvas.org/ns/context.json',''),(5,0,1628166052,1628166052,1,0,'IIIF2','IIIF2','http://iiif.io/api/presentation/2/context.json',''),(6,0,1628166052,1628166052,1,0,'IIIF3','IIIF3','http://iiif.io/api/presentation/3/context.json','');
/*!40000 ALTER TABLE `tx_dlf_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_libraries`
--

DROP TABLE IF EXISTS `tx_dlf_libraries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_libraries` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(11) NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob NOT NULL,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `index_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `website` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` mediumblob NOT NULL,
  `oai_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `oai_base` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opac_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opac_base` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `union_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `union_base` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `index_name` (`index_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_libraries`
--

LOCK TABLES `tx_dlf_libraries` WRITE;
/*!40000 ALTER TABLE `tx_dlf_libraries` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_libraries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_mail`
--

DROP TABLE IF EXISTS `tx_dlf_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_mail` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `mail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_mail`
--

LOCK TABLES `tx_dlf_mail` WRITE;
/*!40000 ALTER TABLE `tx_dlf_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_metadata`
--

DROP TABLE IF EXISTS `tx_dlf_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_metadata` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(11) NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob NOT NULL,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `index_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `format` int(11) NOT NULL DEFAULT 0,
  `default_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `wrap` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `index_tokenized` smallint(6) NOT NULL DEFAULT 0,
  `index_stored` smallint(6) NOT NULL DEFAULT 0,
  `index_indexed` smallint(6) NOT NULL DEFAULT 0,
  `index_boost` double NOT NULL DEFAULT 1,
  `is_sortable` smallint(6) NOT NULL DEFAULT 0,
  `is_facet` smallint(6) NOT NULL DEFAULT 0,
  `is_listed` smallint(6) NOT NULL DEFAULT 0,
  `index_autocomplete` smallint(6) NOT NULL DEFAULT 0,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `index_name` (`index_name`),
  KEY `index_autocomplete` (`index_autocomplete`),
  KEY `is_sortable` (`is_sortable`),
  KEY `is_facet` (`is_facet`),
  KEY `is_listed` (`is_listed`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_metadata`
--

LOCK TABLES `tx_dlf_metadata` WRITE;
/*!40000 ALTER TABLE `tx_dlf_metadata` DISABLE KEYS */;
INSERT INTO `tx_dlf_metadata` VALUES (1,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1280,NULL,'Rights Information','rights_info',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,0,0,0,0,0,0,0,0),(2,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1152,NULL,'Out Of Print Works','out_of_print',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,0,1,1,0,1,0,0,0),(3,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1088,NULL,'Restrictions on Access','restrictions',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,1,1,1,0,0,0,0,0),(4,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1056,NULL,'Terms of Use','terms',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,1,1,1,0,1,0,0,0),(5,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1040,NULL,'License','license',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,1,1,1,0,1,0,0,0),(6,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1032,NULL,'Coordinates','coordinates',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,1,1,1,0,0,0,0,0),(7,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1028,NULL,'Kitodo Process Number','prod_id',3,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,0,0,0,0,0,0,0,0),(8,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1026,NULL,'OAI Identifier','record_id',3,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,0,1,1,0,0,0,0,0),(9,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1025,NULL,'Union Catalog ID','union_id',2,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,0,1,1,0,0,0,0,0),(10,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,1024,NULL,'OPAC Identifier','opac_id',2,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,0,1,1,0,0,0,0,0),(11,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,768,NULL,'URN','urn',3,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.setContentToCurrent = 1\nvalue.typolink.parameter.current = 1\nvalue.typolink.parameter.prepend = TEXT\nvalue.typolink.parameter.prepend.value = http://nbn-resolving.de/\nvalue.wrap = <dd>|</dd>',0,0,1,1,0,0,0,0,0),(12,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,640,NULL,'PURL','purl',2,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.setContentToCurrent = 1\nvalue.typolink.parameter.current = 1\nvalue.wrap = <dd>|</dd>',0,0,0,0,0,0,0,0,0),(13,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,576,NULL,'Owner','owner',3,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,0,1,1,0,1,0,0,0),(14,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,544,NULL,'Collection(s)','collection',3,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',1,0,1,1,0,1,0,0,0),(15,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,528,NULL,'Language','language',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,0,1,1,0,1,0,0,0),(16,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,520,NULL,'Year of Publication','year',2,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,1,1,1,1,1,1,0,0),(17,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,516,NULL,'Place of Publication','place',2,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',1,1,1,1,1,1,1,0,0),(18,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,514,NULL,'Author','author',2,'','key.wrap = <dt class=\"tx-dlf-metadata-author\">|</dt>\nvalue.required = 1\nvalue.split.token.char = 31\nvalue.split.cObjNum = 1\nvalue.split.1.1 = CASE\nvalue.split.1.1.key.data = register:SPLIT_COUNT\nvalue.split.1.1.0 = LOAD_REGISTER\nvalue.split.1.1.0.tx_dlf_metadata_author_name.current = 1\nvalue.split.1.1.1 = LOAD_REGISTER\nvalue.split.1.1.1.tx_dlf_metadata_author_uri.current = 1\nvalue.postCObject = TEXT\nvalue.postCObject.value = {register:tx_dlf_metadata_author_name}\nvalue.postCObject.value.insertData = 1\nvalue.postCObject.value.stdWrap.typolink.parameter = {register:tx_dlf_metadata_author_uri} _blank external\nvalue.postCObject.value.stdWrap.typolink.parameter.insertData = 1\nvalue.postCObject.value.stdWrap.typolink.title = {register:tx_dlf_metadata_author_name}\nvalue.postCObject.value.stdWrap.typolink.ifNotEmpty = 1\nvalue.wrap = <dd class=\"tx-dlf-metadata-author\">|</dd>',1,1,1,2,1,1,1,1,0),(19,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,513,NULL,'Volume','volume',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,1,0,1,1,0,1,0,0),(20,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,512,NULL,'Title','title',3,'','key.wrap = <dt class=\"tx-dlf-metadata-title\">|</dt>\nvalue.required = 1\nvalue.wrap = <dd class=\"tx-dlf-metadata-title\">|</dd>',1,1,1,2,1,0,1,1,0),(21,2,1628486790,1628486790,1,0,0,0,'a:14:{s:5:\"label\";N;s:10:\"index_name\";N;s:6:\"format\";N;s:13:\"default_value\";N;s:4:\"wrap\";N;s:15:\"index_tokenized\";N;s:12:\"index_stored\";N;s:13:\"index_indexed\";N;s:11:\"index_boost\";N;s:11:\"is_sortable\";N;s:8:\"is_facet\";N;s:9:\"is_listed\";N;s:18:\"index_autocomplete\";N;s:16:\"sys_language_uid\";N;}',0,256,NULL,'Type','type',1,'','key.wrap = <dt>|</dt>\nvalue.required = 1\nvalue.wrap = <dd>|</dd>',0,1,0,1,1,1,1,0,0);
/*!40000 ALTER TABLE `tx_dlf_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_metadataformat`
--

DROP TABLE IF EXISTS `tx_dlf_metadataformat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_metadataformat` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `encoded` int(11) NOT NULL DEFAULT 0,
  `xpath` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `xpath_sorting` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mandatory` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_metadataformat`
--

LOCK TABLES `tx_dlf_metadataformat` WRITE;
/*!40000 ALTER TABLE `tx_dlf_metadataformat` DISABLE KEYS */;
INSERT INTO `tx_dlf_metadataformat` VALUES (1,2,1628486790,1628486790,1,0,1,1,'./mods:accessCondition[@type=\"info\"]','',0),(2,2,1628486790,1628486790,1,0,2,1,'./mods:accessCondition[@type=\"out of print work\"]','',0),(3,2,1628486790,1628486790,1,0,3,1,'./mods:accessCondition[@type=\"restriction on access\"]/@xlink:href','',0),(4,2,1628486790,1628486790,1,0,4,1,'./mods:accessCondition[@type=\"local terms of use\"]/@xlink:href','',0),(5,2,1628486790,1628486790,1,0,5,1,'./mods:accessCondition[@type=\"use and reproduction\"]/@xlink:href','',0),(6,2,1628486790,1628486790,1,0,6,1,'./mods:subject/mods:cartographics/mods:coordinates','',0),(7,2,1628486790,1628486790,1,0,7,5,'$.metadata.[?(@.label==\'Kitodo\')].value','',0),(8,2,1628486790,1628486790,1,0,7,2,'./teihdr:fileDesc/teihdr:publicationStmt/teihdr:idno[@type=\"kitodo\"]','',0),(9,2,1628486790,1628486790,1,0,7,1,'./mods:identifier[@type=\"kitodo\"]','',0),(10,2,1628486790,1628486790,1,0,8,5,'$[\'@id\']','',0),(11,2,1628486790,1628486790,1,0,8,2,'./teihdr:fileDesc/teihdr:publicationStmt/teihdr:idno[@type=\"recordIdentifier\"]','',0),(12,2,1628486790,1628486790,1,0,8,1,'./mods:recordInfo/mods:recordIdentifier','',0),(13,2,1628486790,1628486790,1,0,9,2,'./teihdr:fileDesc/teihdr:publicationStmt/teihdr:idno[@type=\"mmid\"]','',0),(14,2,1628486790,1628486790,1,0,9,1,'./mods:identifier[@type=\"ppn\"]','',0),(15,2,1628486790,1628486790,1,0,10,2,'./teihdr:fileDesc/teihdr:publicationStmt/teihdr:idno[@type=\"opac\"]','',0),(16,2,1628486790,1628486790,1,0,10,1,'./mods:identifier[@type=\"opac\"]','',0),(17,2,1628486790,1628486790,1,0,11,5,'$.metadata.[?(@.label==\'URN\')].value','',0),(18,2,1628486790,1628486790,1,0,11,2,'./teihdr:fileDesc/teihdr:publicationStmt/teihdr:idno[@type=\"urn\"]','',0),(19,2,1628486790,1628486790,1,0,11,1,'./mods:identifier[@type=\"urn\"]','',0),(20,2,1628486790,1628486790,1,0,12,2,'./teihdr:fileDesc/teihdr:publicationStmt/teihdr:idno[@type=\"purl\"]','',0),(21,2,1628486790,1628486790,1,0,12,1,'./mods:identifier[@type=\"purl\"]','',0),(22,2,1628486790,1628486790,1,0,13,5,'$.metadata.[?(@.label==\'Owner\')].value','',0),(23,2,1628486790,1628486790,1,0,13,2,'./teihdr:fileDesc/teihdr:publicationStmt/teihdr:publisher','',0),(24,2,1628486790,1628486790,1,0,13,1,'./mods:name[./mods:role/mods:roleTerm=\"own\"]/mods:displayForm','',0),(25,2,1628486790,1628486790,1,0,14,5,'$.metadata.[?(@.label==\'Collection\')].value','',0),(26,2,1628486790,1628486790,1,0,14,2,'./teihdr:fileDesc/teihdr:sourceDesc/teihdr:msDesc/teihdr:msIdentifier/teihdr:collection','',0),(27,2,1628486790,1628486790,1,0,14,1,'./mods:classification','',0),(28,2,1628486790,1628486790,1,0,15,1,'./mods:language/mods:languageTerm','',0),(29,2,1628486790,1628486790,1,0,16,5,'$.metadata.[?(@.label==\'Date of publication\')].value','',0),(30,2,1628486790,1628486790,1,0,16,2,'./teihdr:fileDesc/teihdr:sourceDesc/teihdr:msDesc/teihdr:head/teihdr:origDate','./teihdr:fileDesc/teihdr:sourceDesc/teihdr:msDesc/teihdr:head/teihdr:origDate/@when',0),(31,2,1628486790,1628486790,1,0,17,5,'$.metadata.[?(@.label==\'Place of publication\')].value','',0),(32,2,1628486790,1628486790,1,0,17,2,'./teihdr:fileDesc/teihdr:sourceDesc/teihdr:msDesc/teihdr:head/teihdr:origPlace','',0),(33,2,1628486790,1628486790,1,0,18,5,'$.metadata.[?(@.label==\'Author\')].value','',0),(34,2,1628486790,1628486790,1,0,18,2,'./teihdr:fileDesc/teihdr:sourceDesc/teihdr:msDesc/teihdr:head/teihdr:name','',0),(35,2,1628486790,1628486790,1,0,19,1,'./mods:part/mods:detail/mods:number','./mods:part[@type=\"host\"]/@order',0),(36,2,1628486790,1628486790,1,0,20,5,'$[label]','',0),(37,2,1628486790,1628486790,1,0,20,2,'./teihdr:fileDesc/teihdr:sourceDesc/teihdr:msDesc/teihdr:head/teihdr:note[@type=\"caption\"]','',0),(38,2,1628486790,1628486790,1,0,20,1,'concat(./mods:titleInfo/mods:nonSort,\" \",./mods:titleInfo/mods:title)','./mods:titleInfo/mods:title',0),(39,2,1628486790,1628486790,1,0,21,5,'$.metadata.[?(@.label==\'Manifest Type\')].value','',0);
/*!40000 ALTER TABLE `tx_dlf_metadataformat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_printer`
--

DROP TABLE IF EXISTS `tx_dlf_printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_printer` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `print` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_printer`
--

LOCK TABLES `tx_dlf_printer` WRITE;
/*!40000 ALTER TABLE `tx_dlf_printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_relations`
--

DROP TABLE IF EXISTS `tx_dlf_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_relations` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `ident` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `local_foreign` (`uid_local`,`uid_foreign`,`ident`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_relations`
--

LOCK TABLES `tx_dlf_relations` WRITE;
/*!40000 ALTER TABLE `tx_dlf_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_solrcores`
--

DROP TABLE IF EXISTS `tx_dlf_solrcores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_solrcores` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `index_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `index_name` (`index_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_solrcores`
--

LOCK TABLES `tx_dlf_solrcores` WRITE;
/*!40000 ALTER TABLE `tx_dlf_solrcores` DISABLE KEYS */;
INSERT INTO `tx_dlf_solrcores` VALUES (1,2,0,0,0,0,'newspaper-issues','newspaper-issues');
/*!40000 ALTER TABLE `tx_dlf_solrcores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_structures`
--

DROP TABLE IF EXISTS `tx_dlf_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_structures` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(11) NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob NOT NULL,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toplevel` smallint(6) NOT NULL DEFAULT 0,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `index_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `oai_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `thumbnail` int(11) NOT NULL DEFAULT 0,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `index_name` (`index_name`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_structures`
--

LOCK TABLES `tx_dlf_structures` WRITE;
/*!40000 ALTER TABLE `tx_dlf_structures` DISABLE KEYS */;
INSERT INTO `tx_dlf_structures` VALUES (1,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Year','year','',0,0),(2,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Volume','volume','',0,0),(3,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Verse','verse','',0,0),(4,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Titlepage','title_page','',0,0),(5,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Text','text','',0,0),(6,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Table','table','',0,0),(7,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Subinventory','subinventory','',0,0),(8,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Study','study','',0,0),(9,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Stamp','stamp','',0,0),(10,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Spine','spine','',0,0),(11,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Section','section','',0,0),(12,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Seal','seal','',0,0),(13,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Scheme','scheme','',0,0),(14,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Research Paper','research_paper','',0,0),(15,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Report','report','',0,0),(16,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Register','register','',0,0),(17,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Provenance','provenance','',0,0),(18,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Proceeding','proceeding','',0,0),(19,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Privileges','privileges','',0,0),(20,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Printers Mark','printers_mark','',0,0),(21,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Printed Archives','printed_archives','',0,0),(22,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Preprint','preprint','',0,0),(23,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Preface','preface','',0,0),(24,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Poster','poster','',0,0),(25,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Plan','plan','',0,0),(26,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Photograph','photograph','',0,0),(27,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Periodical','periodical','',0,0),(28,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Paste Down','paste_down','',0,0),(29,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Paper','paper','',0,0),(30,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Page','page','',0,0),(31,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Ornament','ornament','',0,0),(32,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Official Notification','official_notification','',0,0),(33,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Note','note','',0,0),(34,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Newspaper','newspaper','',0,0),(35,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Musical Notation','musical_notation','',0,0),(36,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Multivolume Work','multivolume_work','',0,0),(37,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Month','month','',0,0),(38,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Monograph','monograph','',0,0),(39,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Map','map','',0,0),(40,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Manuscript','manuscript','',0,0),(41,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Master Thesis','master_thesis','',0,0),(42,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Magister Thesis','magister_thesis','',0,0),(43,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Letter','letter','',0,0),(44,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Lecture','lecture','',0,0),(45,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Leaflet','leaflet','',0,0),(46,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Land Register','land_register','',0,0),(47,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Judgement','judgement','',0,0),(48,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Issue','issue','',0,0),(49,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Inventory','inventory','',0,0),(50,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Initial Decoration','initial_decoration','',0,0),(51,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Index','index','',0,0),(52,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Imprint','imprint','',0,0),(53,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Image','image','',0,0),(54,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Illustration','illustration','',0,0),(55,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Habilitation Thesis','habilitation_thesis','',0,0),(56,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Ground Plan','ground_plan','',0,0),(57,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Fragment','fragment','',0,0),(58,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Folder','folder','',0,0),(59,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'File','file','',0,0),(60,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Fascicle','fascicle','',0,0),(61,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Ephemera','ephemera','',0,0),(62,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Entry','entry','',0,0),(63,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Engraved Titlepage','engraved_titlepage','',0,0),(64,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Endsheet','endsheet','',0,0),(65,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Edge','edge','',0,0),(66,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Dossier','dossier','',0,0),(67,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Document','document','',0,0),(68,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Doctoral Thesis','doctoral_thesis','',0,0),(69,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Diploma Thesis','diploma_thesis','',0,0),(70,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Dedication','dedication','',0,0),(71,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Day','day','',0,0),(72,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Back Cover','cover_back','',0,0),(73,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Front Cover','cover_front','',0,0),(74,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Cover','cover','',0,0),(75,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Corrigenda','corrigenda','',0,0),(76,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Table of Contents','contents','',0,0),(77,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Contained Work','contained_work','',0,0),(78,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Colophon','colophon','',0,0),(79,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Collation','collation','',0,0),(80,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Chapter','chapter','',0,0),(81,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Cartulary','cartulary','',0,0),(82,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Bookplate','bookplate','',0,0),(83,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Binding','binding','',0,0),(84,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Bachelor Thesis','bachelor_thesis','',0,0),(85,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Atlas','atlas','',0,0),(86,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Article','article','',0,0),(87,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Annotation','annotation','',0,0),(88,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Album','album','',0,0),(89,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Address','address','',0,0),(90,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,0,'Additional','additional','',0,0),(91,2,1628486788,1628486788,1,0,0,0,'a:6:{s:8:\"toplevel\";N;s:5:\"label\";N;s:10:\"index_name\";N;s:8:\"oai_name\";N;s:9:\"thumbnail\";N;s:16:\"sys_language_uid\";N;}',0,NULL,1,'Act','act','',0,0);
/*!40000 ALTER TABLE `tx_dlf_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_dlf_tokens`
--

DROP TABLE IF EXISTS `tx_dlf_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_dlf_tokens` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `options` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ident` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_dlf_tokens`
--

LOCK TABLES `tx_dlf_tokens` WRITE;
/*!40000 ALTER TABLE `tx_dlf_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_dlf_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `repository` int(10) unsigned NOT NULL DEFAULT 1,
  `version` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`repository`),
  KEY `index_extrepo` (`extension_key`,`repository`),
  KEY `index_versionrepo` (`integer_version`,`repository`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_repository`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_repository` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wsdl_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mirror_list_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_count` int(11) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_repository`
--

LOCK TABLES `tx_extensionmanager_domain_model_repository` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` DISABLE KEYS */;
INSERT INTO `tx_extensionmanager_domain_model_repository` VALUES (1,'TYPO3.org Main Repository','Main repository on typo3.org. This repository has some mirrors configured which are available with the mirror url.','https://typo3.org/wsdl/tx_ter_wsdl.php','https://repositories.typo3.org/mirrors.xml.gz',1346191200,0,0);
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user_uid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastexecution_context` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-22  8:38:21
